///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  OpenGLExample
//
//  Example program using libOpenGL. Displays a ripple on a 3D surface and animates it.
//
//  This is free and unencumbered software released into the public domain - July 2013 waterjuice.org
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  IMPORTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <sys/timeb.h>
#include <stdio.h>
#include <math.h>
#include "libOpenGL.h"

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  CONSTANTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define MAX_MESH_GRID_POINTS    1000

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  PROTOTYPES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

typedef 
double
    (*PlotFunction3D)
    (
        double  X,
        double  Y,
        double  SecondsPassed
    );

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  TYPES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
typedef struct
{
    double meshX [MAX_MESH_GRID_POINTS+1][MAX_MESH_GRID_POINTS+1];
    double meshY [MAX_MESH_GRID_POINTS+1][MAX_MESH_GRID_POINTS+1];
    double meshZ [MAX_MESH_GRID_POINTS+1][MAX_MESH_GRID_POINTS+1];
} MeshPoints;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  GLOBALS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static MeshPoints*      gMeshPoints = NULL;
// Set defaults
static int              gNumMeshPoints  = 200;      
static int              gFrameDelay     = 25;
static int              gWindowSize     = 400;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  GetMilliSecondTime
//
//  Gets a 64bit number containing the number of milliseconds since 1-1-1970
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
uint64_t
    GetMilliSecondTime
    (
        void
    )
{
    struct timeb    timeValue = {0};
    uint64_t        milliseconds;

    ftime( &timeValue );
    milliseconds = ((uint64_t)timeValue.time) * 1000ULL;
    milliseconds += timeValue.millitm;

    return milliseconds;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  CalculateMeshCoordinates
//
//  Calculates the 3D coordinates for the mesh using the plot function
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    CalculateMeshCoordinates
    (
        PlotFunction3D  Function,
        double          SecondsPassed,
        MeshPoints*     MeshCoords
    )
{
    double x;
    double y;
    double z;
    int ix;
    int iy;

    for( ix=0; ix<=gNumMeshPoints; ix++ )
    {
        x = (double)ix / gNumMeshPoints;
        for( iy=0; iy<=gNumMeshPoints; iy++ )
        {
            y = (double)iy / gNumMeshPoints;

            // call plot function to get Z
            z = Function( x, y, SecondsPassed );
            if( z < 0.0 ) { z = 0.0; }
            if( z > 1.0 ) { z = 1.0; }

            MeshCoords->meshX[ix][iy] = ((x*2)-1)*0.7;
            MeshCoords->meshY[ix][iy] = ((y*2)-1)*0.7;
            MeshCoords->meshZ[ix][iy] = (((z*2)-1)*0.7)+0.3;
        }
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  RippleFunction
//
//  This function is a 3d plot function. It provides a Z value for given X and Y. All values are between 0 and 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
double
    RippleFunction
    (
        double  x,
        double  y,
        double  seconds
    )
{
    double pi = 3.14159265358979;
    double z;
    double dist;
    double wave;
    double posX;
    double posY;
    double factor;

    // Get distance of point from centre (0.5, 0.5)
    posX = 0.5;
    posY = 0.5;
    dist = sqrt( (posX-x)*(posX-x) + (posY-y)*(posY-y) );

    wave = sin( 4*(2*pi) * dist - (seconds/1.0) ) * 0.4;
    z = (wave / 2.0) + 0.5;
    z *= (1.0-dist*1.2);

    // Now calculate a second wave with a moving centre and a low amplitude and low
    // frequence wave.
    // Get Distance of point from moving centre
    posX = 0.8 * (sin( (2*pi)*seconds))*0.01;
    posY = 0.8 * (sin( (4*pi)*seconds/2))*0.01;
    dist = sqrt( (posX-x)*(posX-x) + (posY-y)*(posY-y) );
    wave = sin( 2*(2*pi) * dist - (seconds/2.0) ) * 0.05;

    // Apply the second wave to first as a factor that varies over a sine wave
    factor = 1.0 - (cos( ((2*pi) * seconds/40) ) + 1.0) / 2.0;
    z += (wave * factor);

    return z;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  CalcSurfaceNormal
//
//  Calculates the surface normal of the triangle
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    CalcSurfaceNormal
    (
        double      x1,
        double      y1,
        double      z1,
        double      x2,
        double      y2,
        double      z2,
        double      x3,
        double      y3,
        double      z3,
        double*     pNormalX,
        double*     pNormalY,
        double*     pNormalZ
    )
{
    double  d1x;
    double  d1y;
    double  d1z;
    double  d2x;
    double  d2y;
    double  d2z;
    double  crossx;
    double  crossy;
    double  crossz;
    double  dist;

    d1x = x2 - x1;
    d1y = y2 - y1;
    d1z = z2 - z1;

    d2x = x3 - x2;
    d2y = y3 - y2;
    d2z = z3 - z3;

    crossx = d1y*d2z - d1z*d2y;
    crossy = d1y*d2x - d1x*d2z;
    crossz = d1x*d2y - d1y*d2x;

    dist = sqrt( crossx*crossx + crossy*crossy + crossz*crossz );

    *pNormalX = crossx / dist;
    *pNormalY = crossy / dist;
    *pNormalZ = crossz / dist;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  DrawMesh
//
//  Draws the mesh using OpenGL functions
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    DrawMesh
    (
        MeshPoints*     Mesh
    )
{
    int ix;
    int iy;
    double normalX;
    double normalY;
    double normalZ;

    // Draw two triangles between sets of 4 points
    for( iy=gNumMeshPoints; iy>0; iy-- )
    {
        for( ix=1; ix<=gNumMeshPoints; ix++ )
        {
            CalcSurfaceNormal(
                Mesh->meshX[ix-1][iy-1], Mesh->meshY[ix-1][iy-1], Mesh->meshZ[ix-1][iy-1],
                Mesh->meshX[ix-1][iy], Mesh->meshY[ix-1][iy], Mesh->meshZ[ix-1][iy],
                Mesh->meshX[ix][iy-1], Mesh->meshY[ix][iy-1], Mesh->meshZ[ix][iy-1],
                &normalX, &normalY, &normalZ );

            glBegin( GL_TRIANGLES );

            glNormal3d( normalX, normalY, normalZ );
            glVertex3d( Mesh->meshX[ix-1][iy-1], Mesh->meshY[ix-1][iy-1], Mesh->meshZ[ix-1][iy-1] );
            glVertex3d( Mesh->meshX[ix-1][iy], Mesh->meshY[ix-1][iy], Mesh->meshZ[ix-1][iy] );
            glVertex3d( Mesh->meshX[ix][iy-1], Mesh->meshY[ix][iy-1], Mesh->meshZ[ix][iy-1] );

            glNormal3d( normalX, normalY, normalZ );
            glVertex3d( Mesh->meshX[ix][iy-1], Mesh->meshY[ix][iy-1], Mesh->meshZ[ix][iy-1] );
            glVertex3d( Mesh->meshX[ix-1][iy], Mesh->meshY[ix-1][iy], Mesh->meshZ[ix-1][iy] );
            glVertex3d( Mesh->meshX[ix][iy], Mesh->meshY[ix][iy], Mesh->meshZ[ix][iy] );

            glEnd( );
        }
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  DrawFunction
//
//  Called by LibOpenGL
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    DrawFunction
    (
        void
    )
{
    static uint64_t startTime = 0;
    double seconds;
    double  angle = 240;
    static int origNumMeshPoints = 0;

    if( 0 == origNumMeshPoints )
    {
        origNumMeshPoints = gNumMeshPoints;
    }

    if( !startTime )
    {
        startTime = GetMilliSecondTime( );
        seconds = 0.0;
    }
    else
    {
        seconds = ((double)(GetMilliSecondTime( ) - startTime)) / 1000.0;
    }

    CalculateMeshCoordinates( RippleFunction, seconds, gMeshPoints );

	glClearColor( 0.0f, 0.0f, 0.0f, 0.0f );
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    glEnable(GL_DEPTH_TEST); 
    glEnable(GL_POLYGON_SMOOTH);
    glEnable( GL_LIGHTING );
    glEnable( GL_LIGHT0 );
    glShadeModel (GL_SMOOTH);

    glPushMatrix( );

    glRotated( angle, 1.0, 0.5, 0.0 );
	glRotated( angle/2, 0.0, 0.0, 0.1 );


    {
        GLfloat mat_specular[] = { 1.0, 0.5, 0.5, 1.0 };
        GLfloat mat_shininess[] = { 40.0 };
        GLfloat light_position[] = { -1.0, 2.0, -1.0, 0.0 };
        GLfloat light_ambient[] = { 0.5, 0.5, 0.5, 1.0 };
        GLfloat light_diffuse[] = { 1.0, 0.8f, 0.0, 1.0 };
        GLfloat light_specular[] = { 1.0, 0.9f, 0.0, 1.0 };

        glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
        glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
        glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);

        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess);
        glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    }


    DrawMesh( gMeshPoints );

    glPopMatrix( );

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  main
//
//  Entry point
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int
    main
    (
        int     ArgC,
        char*   ArgV[]
    )
{
    // Allocate space for the mesh points (This saves reallocating in the draw loop)
    gMeshPoints = malloc( sizeof(MeshPoints) );

    if( 1 == ArgC )
    {
        // Allow defaults
    }
    else if( 4 == ArgC )
    {
        gWindowSize = atoi( ArgV[1] );
        gNumMeshPoints = atoi( ArgV[2] );
        gFrameDelay = atoi( ArgV[3] );

        if( gWindowSize < 32 || gWindowSize > 2000 )
        {
            printf( "Invalid window size\n" );
            return 1;
        }
        if( gNumMeshPoints < 2 || gNumMeshPoints > MAX_MESH_GRID_POINTS )
        {
            printf( "Invalid number of mesh points\n" );
            return 1;
        }
        if( gFrameDelay < 10 || gFrameDelay > 1000 )
        {
            printf( "Invalid frame delay\n" );
            return 1;
        }
    }
    else
    {
        printf( 
            "Syntax\n"
            "   OpenGLExample <WindowSize> <MeshPoints> <FrameDelay>\n" );
        return 1;
    }


    OpenGLRun( (uint16_t)gWindowSize, (uint16_t)gWindowSize, "OpenGL", DrawFunction, gFrameDelay );

    free( gMeshPoints );

    return 0;
}
