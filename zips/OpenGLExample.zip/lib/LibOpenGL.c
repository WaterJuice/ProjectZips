///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  LibOpenGL
//
//  This library provides a simple cross platform wrapper around window creation for OpenGL. For OSX and Linux this
//  is just a wrapper for GLUT. For Windows it provides a simple window create and message loop wrapper.
//
//  Version 0.1.0 - This code is still in development and should not be considered complete or stable
//
//  This is free and unencumbered software released into the public domain - July 2013 waterjuice.org
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#if defined( _WIN32 )
    #define USE_WIN32
#else
    #define USE_GLUT
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  IMPORTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "LibOpenGL.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>

#if defined( _WIN32 )
    #include <Windows.h>
#pragma comment( lib, "Opengl32.lib" )
#else
    #include <sched.h>
    #include <sys/resource.h>
    #include <unistd.h>
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SETTINGS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef _WIN32
    #pragma warning( disable : 4204 )   // Remove warning about nonstandard non-constant aggregate initializer
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  CONSTANTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define RESOLUTION_X_MIN        32
#define RESOLUTION_X_MAX        2048
#define RESOLUTION_Y_MIN        32
#define RESOLUTION_Y_MAX        2048

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  GLOBALS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static LibOpenGlFunction    gDrawFunction = NULL;
static int                  gTimerElapse = 0;

#ifdef USE_WIN32
    static HWND                 gWindowHandle = NULL;
    static HDC                  gHdc = NULL;
#else
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  INTERNAL FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  WIN32 PROCESSING FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef USE_WIN32

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  WndProc
//
//  Windows Message Handler
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
LRESULT 
CALLBACK 
    WndProc
    (
        HWND    hWnd,
        UINT    message,
        WPARAM  wParam,
        LPARAM  lParam
    )
{
    switch (message)
    {
    case WM_CREATE:
        // Create a timer event so we get polled regularly.
        SetTimer( hWnd, 1, gTimerElapse, NULL );
        break;
    case WM_TIMER:
        gDrawFunction( );
        SwapBuffers( gHdc );
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
        break;
    }

    return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  CreateGraphicsWindowWin32
//
//  Creates the graphics window.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
bool
    CreateGraphicsWindowWin32
    (
        int     ResolutionX,
        int     ResolutionY,
        char*   Title
   )
{
    bool success = false;
    WNDCLASSEX wcex;
    HWND hWnd;
    CHAR className[] = "LibOpenGL";
    PIXELFORMATDESCRIPTOR pfd = {0};
	int format;
    HDC hDC;
    HGLRC hRC;

    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = GetModuleHandle(NULL);
    wcex.hIcon          = NULL;
    wcex.hCursor        = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(INT_PTR)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = NULL;
    wcex.lpszClassName  = className;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE((INT_PTR)IDI_APPLICATION));
    
    if( RegisterClassEx(&wcex) )
    {
        // Adjust rectangle to be size of draw area plus window frames
        RECT wr = {0, 0, ResolutionX, ResolutionY};
        AdjustWindowRect( &wr, WS_OVERLAPPEDWINDOW, FALSE ); 

        // Create the window
        hWnd = CreateWindow(
            className,
            Title,
            WS_OVERLAPPED | WS_CAPTION,
            CW_USEDEFAULT, CW_USEDEFAULT,
            wr.right - wr.left,
            wr.bottom - wr.top,
            NULL,
            NULL,
            GetModuleHandle(NULL),
            NULL
        );

        if( hWnd )
        {
            ShowWindow( hWnd, SW_SHOW );
            UpdateWindow( hWnd );
            gWindowHandle = hWnd;
            success = true;

            // Attach OpenGL to this window
	        // get the device context (DC)
	        hDC = GetDC( hWnd );
            gHdc = hDC;
	
	        // set the pixel format for the DC
	        pfd.nSize = sizeof( pfd );
	        pfd.nVersion = 1;
	        pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
	        pfd.iPixelType = PFD_TYPE_RGBA;
	        pfd.cColorBits = 24;
	        pfd.cDepthBits = 16;
	        pfd.iLayerType = PFD_MAIN_PLANE;
	        format = ChoosePixelFormat( hDC, &pfd );
	        SetPixelFormat( hDC, format, &pfd );
	
	        // create and enable the render context (RC)
	        hRC = wglCreateContext( hDC );
	        wglMakeCurrent( hDC, hRC );
        }
        else
        {
            // CreateWindow failed
            success = false;
        }
    }
    else
    {
        // Failed to register class
        success = false;
    }

    return success;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  IterateMessageLoopWin32
//
//  Performs an iteration of the Windows Message loop
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void
    IterateMessageLoopWin32
    (
        void 
    )
{
    MSG msg;

    GetMessage( &msg, gWindowHandle, 0, 0 );
    TranslateMessage( &msg);
    DispatchMessage( &msg);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#endif // USE_WIN32

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  OPENGL PRIVATE FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef USE_GLUT

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Display
//
//  Called by OpenGL to perform the drawing
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void
    Display
    (
        void
    )
{
    gDrawFunction( );
    glutSwapBuffers();
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  TimerFunc
//
//  Called by OpenGL in as the timer function
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void
    TimerFunc
    (
        int     Unused
    )
{
    Display( );

    // Reset our timer to get triggered again
    glutTimerFunc( gTimerElapse, TimerFunc, 0 );
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  CreateGraphicsWindowOpenGL
//
//  Creates the graphics window.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
bool
    CreateGraphicsWindowOpenGL
    (
        int     ResolutionX,        // [in]
        int     ResolutionY,        // [in]
        char*   Title               // [in]
    )
{
    char* argv[] = { "Hello" };
    int argc = 1;

    // Initializes glut
    glutInit( &argc, argv );

    // Sets up a double buffer with RGBA components
    glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGB );
                                    
    // Sets the window size
    glutInitWindowSize( ResolutionX, ResolutionY );

    // Sets the window position to the upper left
    glutInitWindowPosition(0, 0);

    // Creates a window using internal glut functionality
    glutCreateWindow( Title );

    // passes display function to the OpenGL machine for callback
    glutDisplayFunc( Display );
    glutTimerFunc( gTimerElapse, TimerFunc, 0 );

    glClearColor(1.0, 1.0, 1.0, 0.0);
    glEnable(GL_DEPTH_TEST);
    glShadeModel(GL_SMOOTH);

    return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#endif //USE_GLUT

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  COMMON PRIVATE FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  FUNCTION REDIRECTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef USE_WIN32
    #define CreateGraphicsWindow( X, Y, Title )        CreateGraphicsWindowWin32( (X), (Y), (Title) )
    #define IterateMessageLoop( )                      IterateMessageLoopWin32( )
#else
    #define CreateGraphicsWindow( X, Y, Title )        CreateGraphicsWindowOpenGL( (X), (Y), (Title) )
    #ifdef __APPLE__
        #define IterateMessageLoop( )                      glutCheckLoop( )
    #else
        #define IterateMessageLoop( )                      glutMainLoopEvent( )
    #endif
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  PUBLIC FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  OpenGLRun
//
//  Starts the OpenGL module. This will create a window of the specified size which will be used for OpenGL operations.
//  The DrawFunction will be called when it is time for the window to be drawn as well as each tick of the timer
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool
    OpenGLRun
    (
        uint16_t                ResolutionX,            // [in]
        uint16_t                ResolutionY,            // [in]
        char*                   Title,                  // [in]
        LibOpenGlFunction       DrawFunction,           // [in]
        int                     TimerElapseMilliseconds // [in]
    )
{
    bool    success = false;

    if(     ResolutionX >= RESOLUTION_X_MIN
        &&  ResolutionX <= RESOLUTION_X_MAX
        &&  ResolutionY >= RESOLUTION_Y_MIN
        &&  ResolutionY <= RESOLUTION_Y_MAX
        &&  NULL != Title
        &&  NULL != DrawFunction )
    {
        gDrawFunction = DrawFunction;
        gTimerElapse = TimerElapseMilliseconds;
        success = CreateGraphicsWindow( ResolutionX, ResolutionY, Title );
        if( success )
        {
            // Run Message loop
            for( ;; )
            {
                IterateMessageLoop( );
                #ifdef USE_GLUT
                {
                    // Pause for timer length milliseconds (which is when our timer function is to be triggered)
                    // otherwise CPU usage goes high.
                    usleep( TimerElapseMilliseconds * 1000 );
                }
                #endif
            }
        }
    }
    else
    {
        // Resolution values out of range or other invalid parameters
        success = false;
    }

    return success;
}

