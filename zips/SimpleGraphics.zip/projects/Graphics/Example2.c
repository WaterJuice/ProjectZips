///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SimpleGraphicsTest
//
//  Test program for SimpleGraphics
//
//  This is free and unencumbered software released into the public domain - July 2013 waterjuice.org
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  IMPORTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include "LibSimpleGraphics.h"
#include "Pause.h"

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  CONSTANTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define COLOUR_GRID_BACKGROUND      SgRGB( 220, 220, 220 )
#define COLOUR_GRID_FRAME           SgRGB( 0, 0, 0 )
#define COLOUR_GRID_LINES           SgRGB( 200, 200, 200 )
#define COLOUR_FUNC_PLOT1           SgRGB( 0, 20, 200 )
#define COLOUR_FUNC_PLOT2           SgRGB( 200, 100, 100 )

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  PROTOTYPES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

typedef 
double
    (*PlotFunction)
    (
        double  X
    );

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  DrawGraphGrid
//
//  Draws a graph grid on specified coordinates
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    DrawGraphGrid
    (
        SgPoint     UpperLeft,
        SgPoint     LowerRight
    )
{
    int     i;
    int     width;
    int     height;
    int     stepX;
    int     stepY;

    width = LowerRight.X - UpperLeft.X;
    height = LowerRight.Y - UpperLeft.Y;

    // Draw background
    SgFillRectangle( UpperLeft, LowerRight, COLOUR_GRID_BACKGROUND );
    SgDrawRectangle( UpperLeft, LowerRight, COLOUR_GRID_FRAME );

    stepX = width / 10;
    stepY = height / 10;

    // Draw grid lines
    for( i=1; i<10; i++ )
    {
        SgDrawLine( SgXY( UpperLeft.X+1, UpperLeft.Y+(i*stepY) ), SgXY( LowerRight.X-1, UpperLeft.Y+(i*stepY) ), COLOUR_GRID_LINES );
        SgDrawLine( SgXY( UpperLeft.X+(i*stepX), UpperLeft.Y+1 ), SgXY( UpperLeft.X+(i*stepX), LowerRight.Y-1 ), COLOUR_GRID_LINES );
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  DrawGraphGrid
//
//  Draws a graph grid on specified coordinates
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    DrawPlotFunction
    (
        SgPoint         UpperLeft,
        SgPoint         LowerRight,
        SgColour        Colour,
        PlotFunction    Function
    )
{
    int     i;
    double  width;
    double  height;
    double  x;
    double  y;
    double  lastX = 0;
    double  lastY = 0;

    width = (double)(LowerRight.X - UpperLeft.X);
    height = (double)(LowerRight.Y - UpperLeft.Y);

    for( i=0; i<width; i++ )
    {
        // Scale X for function which accepts value from 0 - 1
        x = (double)i / (double)width;

        // Call function to get y value
        y = Function( x );

        // Constrain result to between 0 and 1
        if( y < 0.0 ) { y = 0.0; }
        if( y > 1.0 ) { y = 1.0; }

        if( i>0 )
        {
            // Draw line segment between this point and the last one
            SgDrawLine( 
                SgXY( UpperLeft.X + (int)(lastX*width), LowerRight.Y - (int)(lastY*height) ),
                SgXY( UpperLeft.X + (int)(x*width), LowerRight.Y - (int)(y*height) ),
                Colour );
        }

        lastX = x;
        lastY = y;

        if( 0 == (i % 3) )
        {
            // Slow down drawing of graph so it looks interesting
            PauseMilliseconds( 10 );
        }
    }

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  WaveFunction1
//
//  A wave function. Takes an X value between 0 and 1 and returns a Y value between 0 and 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
double
    WaveFunction1
    (
        double x
    )
{
    double pi = 3.14159265358979;

    double y;
    double wave;

    wave = sin( 6*(2*pi) * x );

    y = wave * (1.0-x);

    // Scale from -1 - 1 to 0 - 1 for output
    y = (y / 2.0) + 0.5;

    return y;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  WaveFunction1
//
//  A wave function. Takes an X value between 0 and 1 and returns a Y value between 0 and 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
double
    WaveFunction2
    (
        double x
    )
{
    double pi = 3.14159265358979;

    double y;
    double wave1;
    double wave2;
    double wave3;

    wave1 = sin( 5*(2*pi) * x );
    wave2 = sin( 7*(2*pi) * x );
    wave3 = sin( 50*(2*pi) * x );

    y = wave1 * wave2 * wave3 * 0.5;

    // Scale from -1 - 1 to 0 - 1 for output
    y = (y / 2.0) + 0.5;

    return y;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  GraphicsMain
//
//  Graphics function
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    GraphicsMain
    (
        void*   Unused
    )
{
    char buffer [100];
    char* ptr;
    (void) Unused;

    DrawGraphGrid( SgXY(50,50), SgXY(550,550) );
    DrawPlotFunction( SgXY(50,50), SgXY(550,550), COLOUR_FUNC_PLOT2, WaveFunction2 );
    DrawPlotFunction( SgXY(50,50), SgXY(550,550), COLOUR_FUNC_PLOT1, WaveFunction1 );

    // Wait for user to press enter before returning and closing window
    ptr = fgets( buffer, sizeof(buffer), stdin );
    (void)ptr;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  main
//
//  Entry point
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int
    main
    (
        void
    )
{
    SimpleGraphicsRun( 600, 600, "Simple Graphics Example 2", GraphicsMain, 0 );

    return 0;
}