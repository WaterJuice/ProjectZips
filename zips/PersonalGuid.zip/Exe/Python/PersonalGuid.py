#!/usr/bin/env python3
#-----------------------------------------------------------------------------------------------------------------------
#   PersonalGuid
#
#   Creates a "Personal GUID" based on the method specified in http://waterjuice.org/2013/06/personal-guids/
#
#   This is free and unencumbered software released into the public domain - August 2019 waterjuice.org
#-----------------------------------------------------------------------------------------------------------------------

import sys
import uuid

if 7 != len(sys.argv):
    print(
        "PersonalGuid - Version 1.0.1 (August 2019)\n" +
        "Syntax\n" +
        "   PersonalGuid <Surname> <GivenNames> <Sex> <CountryOfBirth> <PlaceOfBirth> <DateOfBirth>\n" +
        "   Sex must be 'F', 'M', or 'X'\n" +
        "   DateOfBirth must be of format YYYYMMDD" )
    exit( 1 )

surname         = sys.argv[1].upper()
givenNames      = sys.argv[2].upper()
sex             = sys.argv[3].upper()
countryOfBirth  = sys.argv[4].upper()
placeOfBirth    = sys.argv[5].upper()
dateOfBirthStr  = sys.argv[6].upper()

# Get gender
if 'M' != sex and 'F' != sex and 'X' != sex:
    print( "Invalid sex specified. Must be 'M', 'F', or 'X'" )
    exit( 1 )

# Get date of birth
if len(dateOfBirthStr) != 8 or not dateOfBirthStr.isdigit():
    print( "Date str must be of format YYYYMMDD" )
    exit( 1 )

# Verify other parameters 
if(     "" == surname 
    or  "" == givenNames
    or  "" == countryOfBirth
    or  "" == placeOfBirth ):
    print( "Incorrect syntax" )
    exit( 1 )

# Assemble id string
idString = "%s;%s;%s;%s;%s;%s" % ( surname, givenNames, sex, countryOfBirth, placeOfBirth, dateOfBirthStr )

print( "ID: %s" % idString );

namespaceGuid = uuid.UUID( '{5b390b3f-9a62-508a-b235-6e6e8d270720}' )

# Create Type 5 GUID
guid = uuid.uuid5( namespaceGuid, idString )
print( '{%s}' % str(guid) )
