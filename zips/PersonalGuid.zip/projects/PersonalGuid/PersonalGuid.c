///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  PersonalGuid
//
//  Creates a "Personal GUID" based on the method specified in http://waterjuice.org/2013/06/personal-guids/
//
//  This is free and unencumbered software released into the public domain - June 2013 waterjuice.org
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  IMPORTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>
#include "LibSha1.h"

#ifdef _WIN32
#pragma warning( disable : 4214 )  // nonstandard extension used : bit field types other than int
#pragma warning( disable : 4201 )  // nonstandard extension used : nameless struct/union
#define snprintf _snprintf
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  TYPES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma pack( push, 1 )
typedef struct
{
    uint8_t     Part1 [4];
    uint8_t     Part2 [2];
    union
    {
        uint8_t     Part3 [2];
        struct
        {
            uint8_t     __1     : 4;
            uint8_t     Version : 4;
        };
    };
    union
    {
        uint8_t     Part4 [2];
        struct
        {
            uint8_t     __2               : 5;
            uint8_t     VariantAdditional : 1;      // Unused for RFC4122 variants
            uint8_t     Variant           : 2;      // Set to 0x2 for RFC4122
        };
    };
    uint8_t     Part5 [6];
} GuidStruct;
#pragma pack( pop )

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  CONSTANTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Name space ID
// {5b390b3f-9a62-508a-b235-6e6e8d270720}
#define GUID_NAME_SPACE_PERSONALGUID    { {0x5b,0x39,0x0b,0x3f}, {0x9a,0x62}, {{0x50,0x8a}}, {{0xb2,0x35}}, {0x6e,0x6e,0x8d,0x27,0x07,0x20} }

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  PRIVATE FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  GuidToString
//
//  Converts a GuidStruct into a string of format: {EDA65727-2E48-4860-809B-ED654D1C55FB}
//  Returns the parameter String so it can be used within a function
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
char*
    GuidToString
    (
        GuidStruct*     Guid,       // [in]
        char*           String,     // [out]
        uint32_t        StringSize  // [in]
    )
{
    if(     NULL == Guid
        ||  NULL == String
        ||  StringSize < 39 )
    {
        // Bad parameters
        return 0;
    }

    memset( String, 0, StringSize );

    sprintf( 
        String,
        "{%2.2x%2.2x%2.2x%2.2x-%2.2x%2.2x-%2.2x%2.2x-%2.2x%2.2x-%2.2x%2.2x%2.2x%2.2x%2.2x%2.2x}",
        Guid->Part1[0], Guid->Part1[1], Guid->Part1[2], Guid->Part1[3],
        Guid->Part2[0], Guid->Part2[1],
        Guid->Part3[0], Guid->Part3[1],
        Guid->Part4[0], Guid->Part4[1],
        Guid->Part5[0], Guid->Part5[1], Guid->Part5[2], Guid->Part5[3], Guid->Part5[4], Guid->Part5[5] );

    return String;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  DupStrUppercase
//
//  Makes a duplicate of the string, but in uppercase. The duplicate string is allocated using malloc and should
//  be deallocated with free.
//  If String is zero length or NULL, then NULL is returned
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
char*
    DupStrUppercase
    (
        char*   String 
    )
{
    int     i;
    int     len;
    char*   newString = 0;

    if( 0 == String )
    {
        return 0;
    }

    len = (int)strlen( String );

    if( len > 0 )
    {
        newString = (char*) malloc( len + 1 );
        if( newString )
        {
            for( i=0; i<len; i++ )
            {
                newString[i] = (char)toupper( (int)String[i] );
            }
            newString[len] = 0;

            return newString;
        }
        else
        {
            // Failed to allocate memory
            printf( "MEMORY FAIL\n" );
            return 0;
        }
    }
    else
    {
        return 0;
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  main
//
//  Program entry point
//  Note: This function does NOT clean up memory it allocates on return.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int
    main
    (
        int             ArgC,
        char**          ArgV
    )
{
    Sha1Context         sha1Context;
    SHA1_HASH           sha1Hash;
    GuidStruct          guid = {{0}};
    GuidStruct          guidNameSpace = GUID_NAME_SPACE_PERSONALGUID;
    char                guidString [40];
    char                idString [1000];
    char*               surname;
    char*               givenNames;
    char*               gender;
    char*               countryOfBirth;
    char*               placeOfBirth;
    char*               dateOfBirthStr;
    int                 i;

    if( 7 != ArgC )
    {
        printf(
            "Syntax\n"
            "   PersonalGuid <Surname> <GivenNames> <Gender> <CountryOfBirth> <PlaceOfBirth> <DateOfBirth>\n"
            "   Gender must be either 'F' or 'M'\n"
            "   DateOfBirth must be of format YYYYMMDD\n" );
        return 1;
    }

    surname         = DupStrUppercase( ArgV[1] );
    givenNames      = DupStrUppercase( ArgV[2] );
    gender          = DupStrUppercase( ArgV[3] );
    countryOfBirth  = DupStrUppercase( ArgV[4] );
    placeOfBirth    = DupStrUppercase( ArgV[5] );
    dateOfBirthStr  = ArgV[6];
    
    // Get gender
    if(     strcmp( gender, "M" ) != 0
        &&  strcmp( gender, "F" ) != 0 ) 
    {
        printf( "Invalid gender specified. Must be either 'M' or 'F'\n" );
        return 1;
    }

    // Get date of birth
    if( strlen( dateOfBirthStr ) != 8 )
    {
        printf( "Date str must be of format YYYYMMDD\n" );
        return 1;
    }

    for( i=0; i<(int)strlen(dateOfBirthStr); i++ )
    {
        if( dateOfBirthStr[i] < '0' || dateOfBirthStr[i] > '9' )
        {
            printf( "Date str must be of format YYYYMMDD\n" );
            return 1;
        }
    }

    // Verify other parameters 
    if(     0 == surname 
        ||  0 == givenNames
        ||  0 == countryOfBirth
        ||  0 == placeOfBirth )
    {
        printf( "Incorrect syntax\n" );
        return 1;
    }

   
    // Assemble id string
    snprintf( 
        idString, sizeof(idString), 
        "%s;%s;%s;%s;%s",
        surname,
        givenNames,
        gender,
        countryOfBirth,
        placeOfBirth );
    idString[sizeof(idString)-1] = 0;

    printf( "ID: %s\n", idString );

    // Calculate SHA1 of namespace and name
    Sha1Initialise( &sha1Context );
    Sha1Update( &sha1Context, &guidNameSpace, sizeof(guidNameSpace) );
    Sha1Update( &sha1Context, idString, (uint32_t)strlen(idString) );
    Sha1Finalise( &sha1Context, &sha1Hash );
    
    // Create Type 5 GUID
    memcpy( &guid, &sha1Hash, sizeof(guid) );
    guid.Version = 5;       // Type 5 (SHA1)
    guid.Variant = 0x2;     // RFC4122 variant
    GuidToString( &guid, guidString, sizeof(guidString) );
    printf( "%s\n", guidString );

    return 0;
}

