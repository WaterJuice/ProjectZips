CMakeSample
===========

This is a sample "Hello World" program to demonstrate the use of a CMake file. This project contains one root 
CMakeLists.txt file that defines a library and an executable that links to the library. 

To build the sample executable for your platform the following command can be run from the root directory where the 
`CMakeLists.txt` file resides 

`cmake -H. -Bbuild -CMAKE_INSTALL_PREFIX=bin`
`cmake --build build --target install`

This will create the build system and build the binaries and place them in the subdirectory `bin`

The first command generates the build system for your platform. In Windows this will probably be Visual Studio, in 
Linux this will probably be gcc and make. The parameter `-H.` says "source file starts here". `-Bbuild` says "put the 
build system into the subfolder `build`". The `-CMAKE_INSTALL_PREFIX=bin` says "When building with `--target 
install`, make the directory the subfolder `bin`" 

The second command says "build using the build system in subdirectory build and place the executables in the install 
location specified before (`bin`)" 

It is highly recommended to always perform an "out-of-source" build. You can however build "in-source" with the 
following simpler commands: 

`cmake .`
`cmake --build .`

This will however places the builds files all over the place in the directory and is generally considered messy. 
However if you are just wanting to get the binaries build with the least fuss, and are not planning to actually to 
use the source files for coding then this is the quickest way. In this example we did not specify the install 
location. The binaries will be built in the source tree and not copied to the install location. 

License
=======

This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or distribute this software, either in source code form 
or as a compiled binary, for any purpose, commercial or non-commercial, and by any means. 

In jurisdictions that recognize copyright laws, the author or authors of this software dedicate any and all copyright 
interest in the software to the public domain. We make this dedication for the benefit of the public at large and to 
the detriment of our heirs and successors. We intend this dedication to be an overt act of relinquishment in 
perpetuity of all present and future rights to this software under copyright law. 

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS BE 
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 

For more information, please refer to <http://unlicense.org/>

*Created November 2017 - waterjuice.org *             
