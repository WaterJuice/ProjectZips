///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  ProofOfWork
//
//  This program is a demonstration of the "proof of work" concept. It appends random characters to a string in order
//  to produce an MD5 hash with "the largest value". The program attempts to find larger and larger hash values. The
//  time taken to find each subsequent hash takes longer as the threshold rises. The result can be easily verified by 
//  a single MD5 calculation. 
//  
//  This is free and unencumbered software released into the public domain - June 2013 waterjuice.org
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SETTINGS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Disable this define to remove threading support. 
#define ENABLE_THREADING

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  IMPORTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <string.h>
#include <sys/timeb.h>
#include "../lib/LibMd5.h"
#include "../lib/LibRc4.h"
#ifdef ENABLE_THREADING
    #include "../lib/LibThread.h"
#endif

#ifndef ENABLE_THREADING
#define THREADSPINLOCK          uint32_t
#define ThreadSpinLockAcquire( ptr )
#define ThreadSpinLockRelease( ptr )
typedef void (*ThreadStartFunction) ( void* Context );
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  CONSTANTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define MAX_APPENDED_CHARS          16
#define NUM_CHAR_SET                55

#define LOG_AFTER_N_HASHES          1000
#define DISPLAY_AFTER_N_HASHES      20000000

// This table has 55 characters. Letters and numbers without 0,1,i,I,o,O,l
static const char           gCharTable [NUM_CHAR_SET+1] = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  DEFINITIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __min
    #define __min( x, y )  (((x) < (y))?(x):(y))
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  GLOBALS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static uint32_t             gNumCharsAppended = 0;
static char                 gString [1024] = "";

#ifdef ENABLE_THREADING
static THREADSPINLOCK       gPrintSpinLock = 0;
static THREADSPINLOCK       gHashSpinLock = 0;
#endif

static uint64_t             gNumHashes = 0;
static int                  gHasDisplayed = 0;
static uint64_t             gStartTime = 0;

static MD5_HASH             gSmallestHash = { 0x00, 0x00, 0x01 };
static MD5_HASH             gLargestHash  = { 0xff, 0xff, 0xff };

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  INTERNAL FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  GetMilliSecondTime
//
//  Gets a 64bit number containing the number of milliseconds since 1-1-1970
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
uint64_t
    GetMilliSecondTime
    (
        void
    )
{
    struct timeb    timeValue = {0};
    uint64_t        milliseconds;
    
    ftime( &timeValue );
    milliseconds = ((uint64_t)timeValue.time) * 1000ULL;
    milliseconds += timeValue.millitm;
    
    return milliseconds;    
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  FormatTime
//
//  Formats a time (in milliseconds) to a nice human readable format
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
char*
    FormatTime
    (
        char*           String,
        uint32_t        StringSize,
        uint64_t        Milliseconds
    )
{
    uint64_t                days = 0;
    uint64_t                msLeft = 0;
    uint64_t                hours = 0;
    uint64_t                minutes = 0;
    uint64_t                seconds = 0;

    if( StringSize >= 64 )
    {
        msLeft = Milliseconds;

        days = msLeft / ( 1000ULL * 60ULL * 60ULL * 24ULL );
        msLeft %=       ( 1000ULL * 60ULL * 60ULL * 24ULL );

        hours = msLeft / ( 1000ULL * 60ULL * 60ULL );
        msLeft %=        ( 1000ULL * 60ULL * 60ULL );

        minutes = msLeft / ( 1000ULL * 60ULL );
        msLeft %=          ( 1000ULL * 60ULL );

        seconds = msLeft / ( 1000ULL );
        msLeft %=          ( 1000ULL );

        String[0] = 0;

        if( days > 0 )
        {
            sprintf( String+strlen(String), "%u Days + ", (uint32_t)days );
        }
        sprintf( String+strlen(String), "%2.2u:%2.2u:%2.2u (h:m:s)", (uint32_t)hours, (uint32_t)minutes, (uint32_t)seconds );
    }
    else if( StringSize > 0 )
    {
        String[0] = 0;
    }

    return String;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  DisplayHash
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void
    DisplayHash
    (
        char*               AppendedChars,
        MD5_HASH            Md5Hash,
        char*               Description
    )
{
    uint64_t                currentTime;
    uint64_t                numMilliseconds = 0;
    uint32_t                i;
    char                    timeStr [100];

    ThreadSpinLockAcquire( &gPrintSpinLock );
    currentTime = GetMilliSecondTime( );
    numMilliseconds = currentTime - gStartTime;
    {
        printf( "%s%s  ", gString, AppendedChars );

        for( i=0; i<MD5_HASH_SIZE; i++ )
        {
            printf( "%2.2x", Md5Hash.bytes[i] );
        }

        printf( "  %s", Description );
        printf( "  %.3f GHashes", (float)gNumHashes / 1000000000.0 );
        printf( "  in %s\n", FormatTime( timeStr, sizeof(timeStr), numMilliseconds ) );
    }
    ThreadSpinLockRelease( &gPrintSpinLock );
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SeedStreamWithRandom
//
//  Initialises an RC4 stream with a random key
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void
    SeedStreamWithRandom
    (
        Rc4Context*         Context,
        uint8_t             ThreadNum
    )
{
    struct
    {
        uint8_t             threadNum;
        struct timeb        time;
        void*               address;
        ThreadStartFunction address2;
    } seedValues;
    MD5_HASH                hash;
    Md5Context              md5Context;

    seedValues.threadNum = ThreadNum;
    ftime( &seedValues.time );
    seedValues.address = Context;
    seedValues.address2 = (ThreadStartFunction)SeedStreamWithRandom;

    Md5Initialise( &md5Context );
    Md5Update( &md5Context, &seedValues, sizeof(seedValues) );
    Md5Finalise( &md5Context, &hash );

    Rc4Initialise( Context, &hash, sizeof(hash), 0 );
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  MeasureHash
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
double
    MeasureHash
    (
        MD5_HASH            Hash,
        int                 bMeasureLarge
    )
{
    uint32_t    i;
    uint32_t    numFullBytes;
    double      numBitsWorth;
    uint32_t    firstFewNonFull;
    uint32_t    numBytesLeft;

    numFullBytes = 0;
    for( i=0; i<MD5_HASH_SIZE; i++ )
    {
        if(     ( 0x00 == Hash.bytes[i]  &&  !bMeasureLarge )
            ||  ( 0xff == Hash.bytes[i]  &&  bMeasureLarge ) )
        {
            numFullBytes += 1;
        }
        else
        {
            break;
        }
    }

    numBitsWorth = (double)( numFullBytes * 8 );
    numBytesLeft = MD5_HASH_SIZE - numFullBytes;

    if( numFullBytes < MD5_HASH_SIZE )
    {
        firstFewNonFull = 0;
        for( i=0; i<__min(sizeof(firstFewNonFull),numBytesLeft); i++ )
        {
            firstFewNonFull |= ( Hash.bytes[numFullBytes+i] ) << ( 8 * ( sizeof(firstFewNonFull) - i - 1 ) );
        }

        if( bMeasureLarge )
        {
            firstFewNonFull = ~firstFewNonFull;
        }

        numBitsWorth += (sizeof(firstFewNonFull) * 8.0) - ( log( (double)(firstFewNonFull + 1) ) / log( 2.0 ) );
    }

    return numBitsWorth;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  FindProofOfWorkThreadFunction
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void
    FindProofOfWorkThreadFunction
    (
        void*       Parameter
    )
{
    uint8_t*        pThreadNum = (uint8_t*)Parameter;
    Md5Context      initialisedMd5Context;
    Md5Context      md5Context;
    uint8_t         appendedChars [MAX_APPENDED_CHARS + 1] = {0};
    uint32_t        i;
    MD5_HASH        md5Hash;
    uint64_t        numHashes = 0;
    uint64_t        currentTime;
    uint64_t        numMilliseconds = 0;
    MD5_HASH        localSmallestHash;
    MD5_HASH        localLargestHash;
    Rc4Context      randStream;
    double          workMeasure;
    char            msg[100];

    Md5Initialise( &initialisedMd5Context );
    Md5Update( &initialisedMd5Context, gString, strlen( gString ) );
    
    ThreadSpinLockAcquire( &gHashSpinLock );
    {
        localSmallestHash = gSmallestHash;
        localLargestHash = gLargestHash;
    }
    ThreadSpinLockRelease( &gHashSpinLock );

    SeedStreamWithRandom( &randStream, *pThreadNum );

    for( ;; )
    {
        md5Context = initialisedMd5Context;
        
        // Make random string addition
        Rc4Output( &randStream, appendedChars, gNumCharsAppended );

        // Now make them printable characters
        for( i=0; i<gNumCharsAppended; i++ )
        {
            appendedChars[i] = gCharTable[(((uint8_t)appendedChars[i]) % NUM_CHAR_SET)];
        }

        // Calculate hash
        Md5Update( &md5Context, appendedChars, gNumCharsAppended );
        Md5Finalise( &md5Context, &md5Hash );

        numHashes += 1;
        if( numHashes >= LOG_AFTER_N_HASHES )
        {
            ThreadSpinLockAcquire( &gPrintSpinLock );
            {
                gNumHashes += numHashes;
                if( (!gHasDisplayed) && gNumHashes >= DISPLAY_AFTER_N_HASHES )
                {
                    uint64_t        hashesPerSecond;

                    currentTime = GetMilliSecondTime();
                    numMilliseconds = currentTime - gStartTime;
                    hashesPerSecond =  ( 1000 * gNumHashes ) / numMilliseconds;

                    printf( "Hashing rate: %.2f MHash/s\n", (float)hashesPerSecond / 1000000.0 );

                    gHasDisplayed = 1;
                }
            }
            ThreadSpinLockRelease( &gPrintSpinLock );
            numHashes = 0;

        }

        // See if this is larger than current largest hash
        if( memcmp( &md5Hash, &localLargestHash, MD5_HASH_SIZE ) > 0 )
        {
            ThreadSpinLockAcquire( &gHashSpinLock );
            {
                // Now check that this is larger than the current global
                if( memcmp( &md5Hash, &gLargestHash, MD5_HASH_SIZE ) > 0 )
                {
                    gLargestHash= md5Hash;
                    workMeasure = MeasureHash( md5Hash, 1 );
                    sprintf( msg, "Is Larger  (%5.2f)", workMeasure );
                    DisplayHash( (char*)appendedChars, md5Hash, msg );
                }
                localLargestHash = gLargestHash;
            }
            ThreadSpinLockRelease( &gHashSpinLock );
        }

        // See if this is smaller than current smallest hash
        if( memcmp( &md5Hash, &localSmallestHash, MD5_HASH_SIZE ) < 0 )
        {
            ThreadSpinLockAcquire( &gHashSpinLock );
            {
                // Now check that this is larger than the current global
                if( memcmp( &md5Hash, &gSmallestHash, MD5_HASH_SIZE ) < 0 )
                {
                    gSmallestHash= md5Hash;
                    workMeasure = MeasureHash( md5Hash, 0 );
                    sprintf( msg, "Is Smaller (%5.2f)", workMeasure );
                    DisplayHash( (char*)appendedChars, md5Hash, msg );
                }
                localSmallestHash = gSmallestHash;
            }
            ThreadSpinLockRelease( &gHashSpinLock );
        }

    }
}

//---------------------------------------------------------------------------------------
//  EXPORTED FUNCTIONS
//---------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------
//  FUNCTION:       main
//
//  DESCRIPTION:    Entry point
//---------------------------------------------------------------------------------------
int
    main
    (
        int         ArgC,
        char**      ArgV
    )
{
    char*                 string;
    uint32_t              numCharsAdded;
    uint8_t               threadNum [256];
#ifdef ENABLE_THREADING
    uint32_t              numThreads;
    uint32_t              i;
#endif

#ifdef ENABLE_THREADING
    if( ArgC != 4 )
    {
        printf( 
            "Syntax:\n"
            "   ProofOfWork: <string> <numCharsAdded> <numThreads>\n" );
        return 1;
    }
#else
    if( ArgC != 3 )
    {
        printf(
               "Syntax:\n"
               "   ProofOfWork: <string> <numCharsAdded>\n" );
        return 1;
    }
#endif
    
    setbuf( stdout, NULL );   // Remove stdout buffering

    string = ArgV[1];
    numCharsAdded = atoi( ArgV[2] );

#ifdef ENABLE_THREADING
    numThreads = atoi( ArgV[3] );

    if( 0 == numThreads ||  numThreads > 256 )
    {
        printf( "Num threads must be between 1 and 256\n" );
        return 1;
    }
#endif //ENABLE_THREADING
    
    if( numCharsAdded < 2  ||  numCharsAdded > MAX_APPENDED_CHARS )
    {
        printf( "Invalid number of chars to add. Must be between 2 - %u\n", MAX_APPENDED_CHARS );
        return 1;
    }

    gNumCharsAppended = numCharsAdded;
    strcpy( gString, string );

#ifdef ENABLE_THREADING
    ThreadSetProcessPriorityToBackground( );
#endif
    
    gStartTime = GetMilliSecondTime( );

    threadNum[0] = 0;
#ifdef ENABLE_THREADING
    for( i=1; i<numThreads; i++ )
    {
        threadNum[i] = (uint8_t)i;
        ThreadLaunchNewThread ( FindProofOfWorkThreadFunction, &threadNum[i] );
    }
#endif
    FindProofOfWorkThreadFunction( &threadNum[0] );
}
