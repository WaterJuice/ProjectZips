///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  UrlGuid
//
//  This program creates type 3 and type 5 GUIDs (UUIDs) from a URL or DNS name provided on the command line.
//  There are many programs available that generate type 1 and type 4 GUIDs, but there is very little information
//  or usage of type 3 and 5. This was written to demonstate their use.
//
//  This is free and unencumbered software released into the public domain - June 2013 waterjuice.org
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  IMPORTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "../lib/LibMd5.h"
#include "../lib/LibSha1.h"

#ifdef _WIN32
#pragma warning( disable : 4214 )  // nonstandard extension used : bit field types other than int
#pragma warning( disable : 4201 )  // nonstandard extension used : nameless struct/union
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  TYPES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma pack( push, 1 )
typedef struct
{
    uint8_t     Part1 [4];
    uint8_t     Part2 [2];
    union
    {
        uint8_t     Part3 [2];
        struct
        {
            uint8_t     __1     : 4;
            uint8_t     Version : 4;
        };
    };
    union
    {
        uint8_t     Part4 [2];
        struct
        {
            uint8_t     __2               : 5;
            uint8_t     VariantAdditional : 1;      // Unused for RFC4122 variants
            uint8_t     Variant           : 2;      // Set to 0x2 for RFC4122
        };
    };
    uint8_t     Part5 [6];
} GuidStruct;
#pragma pack( pop, 1 )

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  CONSTANTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Name space IDs as defined by RFC4122 Appendix C
#define GUID_NAME_SPACE_DNS     { {0x6b,0xa7,0xb8,0x10}, {0x9d,0xad}, {0x11,0xd1}, {0x80,0xb4}, {0x00,0xc0,0x4f,0xd4,0x30,0xc8} }
#define GUID_NAME_SPACE_URL     { {0x6b,0xa7,0xb8,0x11}, {0x9d,0xad}, {0x11,0xd1}, {0x80,0xb4}, {0x00,0xc0,0x4f,0xd4,0x30,0xc8} }
#define GUID_NAME_SPACE_OID     { {0x6b,0xa7,0xb8,0x12}, {0x9d,0xad}, {0x11,0xd1}, {0x80,0xb4}, {0x00,0xc0,0x4f,0xd4,0x30,0xc8} }
#define GUID_NAME_SPACE_X500    { {0x6b,0xa7,0xb8,0x13}, {0x9d,0xad}, {0x11,0xd1}, {0x80,0xb4}, {0x00,0xc0,0x4f,0xd4,0x30,0xc8} }

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  PRIVATE FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  GuidToString
//
//  Converts a GuidStruct into a string of format: {EDA65727-2E48-4860-809B-ED654D1C55FB}
//  Returns the parameter String so it can be used within a function
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
char*
    GuidToString
    (
        GuidStruct*     Guid,       // [in]
        char*           String,     // [out]
        uint32_t        StringSize  // [in]
    )
{
    if(     NULL == Guid
        ||  NULL == String
        ||  StringSize < 39 )
    {
        // Bad parameters
        return 0;
    }

    memset( String, 0, StringSize );

    sprintf( 
        String,
        "{%2.2x%2.2x%2.2x%2.2x-%2.2x%2.2x-%2.2x%2.2x-%2.2x%2.2x-%2.2x%2.2x%2.2x%2.2x%2.2x%2.2x}",
        Guid->Part1[0], Guid->Part1[1], Guid->Part1[2], Guid->Part1[3],
        Guid->Part2[0], Guid->Part2[1],
        Guid->Part3[0], Guid->Part3[1],
        Guid->Part4[0], Guid->Part4[1],
        Guid->Part5[0], Guid->Part5[1], Guid->Part5[2], Guid->Part5[3], Guid->Part5[4], Guid->Part5[5] );

    return String;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  IsStringUrl
//  
//  Returns true (1) if the string is a valid Url format. 0 otherwise. eg: http://example.com/page.html
//  Note this is a not a strict test, just catches things that are likely to be URLs
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
int
    IsStringUrl
    (
        char*       String
    )
{
    int     i;

    // ensure no spaces
    for( i=0; i<(int)strlen(String); i++ )
    {
        if( ' ' == String[i] )
        {
            return 0;
        }
    }
    
    // Verify it has a "://"
    if( !strstr( String, "://" ) )
    {
        return 0;
    }

    return 1;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  IsStringDns
//
//  Returns true (1) if the string is a valid DNS format. 0 otherwise eg example.com
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
int
    IsStringDns
    (
        char*       String
    )
{
    int     i;

    // ensure only letters digits, and dots
    for( i=0; i<(int)strlen(String); i++ )
    {
        if(     '.' != String[i] 
            &&  '-' != String[i]
            &&  '_' != String[i]
            &&  ( String[i] < 'a'  ||  String[i] > 'z' )
            &&  ( String[i] < 'A'  ||  String[i] > 'Z' )
            &&  ( String[i] < '0'  ||  String[i] > '9' ) )
        {
            return 0;
        }
    }
    
    // Verify it has at least 1 dot
    if( !strstr( String, "." ) )
    {
        return 0;
    }

    return 1;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  main
//
//  Program entry point
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int
    main
    (
        int             ArgC,
        char**          ArgV
    )
{
    char*               UrlString;
    Sha1Context         sha1Context;
    SHA1_HASH           sha1Hash;
    Md5Context          md5Context;
    MD5_HASH            md5Hash;
    GuidStruct          guid = {0};
    GuidStruct          guidNameSpaceDns = GUID_NAME_SPACE_DNS;
    GuidStruct          guidNameSpaceUrl = GUID_NAME_SPACE_URL;
    GuidStruct          guidNameSpace;
    char                guidString [40];

    if( 2 != ArgC )
    {
        printf(
            "Syntax\n"
            "   UrlGuid <Dns/Url>\n" );
        return 1;
    }

    UrlString = ArgV[1];

    // Determine if this is a URL or a dns style name
    if( IsStringUrl( UrlString ) )
    {
        guidNameSpace = guidNameSpaceUrl;
    }
    else if( IsStringDns( UrlString ) )
    {
        guidNameSpace = guidNameSpaceDns;
    }
    else
    {
        printf( "Format of string must either be a URL or a DNS name\n" );
        return 1;
    }

    // Calculate MD5 of namespace and name
    Md5Initialise( &md5Context );
    Md5Update( &md5Context, &guidNameSpace, sizeof(guidNameSpace) );
    Md5Update( &md5Context, UrlString, (uint32_t)strlen(UrlString) );
    Md5Finalise( &md5Context, &md5Hash );

    // Calculate SHA1 of namespace and name
    Sha1Initialise( &sha1Context );
    Sha1Update( &sha1Context, &guidNameSpace, sizeof(guidNameSpace) );
    Sha1Update( &sha1Context, UrlString, (uint32_t)strlen(UrlString) );
    Sha1Finalise( &sha1Context, &sha1Hash );
    
    // Create Type 3 GUID
    memcpy( &guid, &md5Hash, sizeof(guid) );
    guid.Version = 3;       // Type 3 (MD5)
    guid.Variant = 0x2;     // RFC4122 variant
    GuidToString( &guid, guidString, sizeof(guidString) );
    printf( "%s\n", guidString );

    // Create Type 5 GUID
    memcpy( &guid, &sha1Hash, sizeof(guid) );
    guid.Version = 5;       // Type 4 (SHA1)
    guid.Variant = 0x2;     // RFC4122 variant
    GuidToString( &guid, guidString, sizeof(guidString) );
    printf( "%s\n", guidString );

    return 0;
}

