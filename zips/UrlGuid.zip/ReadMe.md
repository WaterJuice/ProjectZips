UrlGuid
=======

This program creates a type 3 and a type 5 GUID (UUID) from either
a DNS name or a URL style string. Note this does not perform case
conversions. So it is is possible to generate different GUIDs with
the same domain using casing. Eg: waterjuice.org and WaterJuice.org
will result in different GUIDs.

Examples:

    waterjuice.org
    Type 3 GUID: {bed9e1fe-7b92-385c-82aa-104c8c45bccf}
    Type 5 GUID: {c1a7f72b-f2ee-5455-590c-308ae1450a0e}

    http://waterjuice.org/c-source-code-for-sha1/
    Type 3 GUID: {509ff9ef-2295-353c-ae53-c4fc3bae440f}
    Type 5 GUID: {685fddde-3c2d-5145-a707-6ea984d003e6}

*Created June 2013*             

License
=======

This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <http://unlicense.org/>

