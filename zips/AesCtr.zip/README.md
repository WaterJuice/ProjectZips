AES and AESCTR
==============

This sample contains C source code for AES and AES-CTR. Their source
files are in the `lib` directory

* CryptLib_Aes.h
* CryptLib_Aes.c
* CryptLib_AesCtr.h
* CryptLib_AesCtr.c

When using AES alone only the first two files are needed. When using AES-CTR
then all are needed.

*Created November 2017 - waterjuice.org *             

Sample Programs
---------------

In the `utils` directory there are two programs that compile to command line
executeables.

* AesBlock
* AesCtrOutput

AesBlock takes a AES key and a 16 byte block in hex and encrypt or decrypt it
and display the result in hex.

AesCtrOuput takes an AES key and 64 bit IV in hex and outputs the specified 
number of bytes to stdout in hex.

Tests
-----

The directory `tests` contains unit tests for both AES and AES-CTR. These
verify that the results are consistent against known test vectors.

Building
--------

A `CMakeLists.txt` is in the root directory so that this project can be built
using CMake.

To build the sample executables and unit tests for your platform the following
command can be run from the root directory where the `CMakeLists.txt` file is

`cmake -H. -Bbuild -CMAKE_INSTALL_PREFIX=bin`
`cmake --build build --target install`

This will build the binaries and place them in the subdirectory `bin`

Executables
-----------

Included in the `Binaries` directory are executables of the above programs for
Windows, OSX, and Linux. All of them are compiled for x64 versions of the operating
systems. 

License
=======

This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <http://unlicense.org/>

