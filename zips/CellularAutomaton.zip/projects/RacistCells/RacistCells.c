///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  RacistCells
//
//  A cell automation program where cells move or stay in their location based on the colour of the neighbouring cells.
//  In each iteration a cell may choose to swap its position with another random cell. The probability that a cell
//  moves gets higher if its surrounding cells are of a different colour to itself.
//  This makes some interesting patterns.
//
//  This is free and unencumbered software released into the public domain - July 2013 waterjuice.org
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  IMPORTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <sys/timeb.h>
#include <stdio.h>
#include <memory.h>
#include "LibOpenGL.h"
#include "LibRc4.h"

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  CONSTANTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define CELL_GRID_SIZE      300
#define NUM_CELL_COLOURS    5

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  TYPES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


typedef struct _Cell
{
    int             CellType;
    struct _Cell*   NeighbourCells[8];
} Cell;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  GLOBALS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static Cell         gUniverse [CELL_GRID_SIZE][CELL_GRID_SIZE];
static Rc4Context   gRc4Context;
static double       CellColourR  [NUM_CELL_COLOURS] = { 1, 0, 1, 0, 0 };
static double       CellColourG  [NUM_CELL_COLOURS] = { 1, 0, 0, 0, 1 };
static double       CellColourB  [NUM_CELL_COLOURS] = { 1, 0, 0, 1, 0 };

static uint8_t      gMovingThreshold [9] = { 20, 50, 60, 200, 210, 220, 250, 253, 255 }; 

static Cell*        gCellsToMove [CELL_GRID_SIZE*CELL_GRID_SIZE];
static int          gNumCellsToMove = 0;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SeedStreamWithRandom
//
//  Initialises the global  RC4 stream with a random key. Note this has a very poor source of entropy, this should not 
//  be used in cryptography.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void
    SeedStreamWithRandom
    (
        void
    )
{
    struct
    {
        struct timeb        time;
        void*               address;
    } seedValues;

    ftime( &seedValues.time );
    seedValues.address = &gRc4Context;

    Rc4Initialise( &gRc4Context, &seedValues, sizeof(seedValues), 0 );
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  InitialUniverseFill
//
//  Fills the universe with cells of random colours. Also sets up the neighbour pointers to point to the correct cells
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    InitialUniverseFill
    (
        void
    )
{
    int x;
    int y;

    SeedStreamWithRandom( );

    // Wipe universe array
    memset( gUniverse, 0, sizeof(gUniverse) );

    // Populate cells with a random distribution
    for( y=0; y<CELL_GRID_SIZE; y++ )
    {
        for( x=0; x<CELL_GRID_SIZE; x++ )
        {
            uint8_t value;
            Rc4Output( &gRc4Context, &value, sizeof(value) );

            gUniverse[x][y].CellType = value % NUM_CELL_COLOURS;
        }
    }

    // Create neighbour pointers
    for( y=0; y<CELL_GRID_SIZE; y++ )
    {
        for( x=0; x<CELL_GRID_SIZE; x++ )
        {
            int neighbourLeft   = (0==x) ? CELL_GRID_SIZE-1 : x-1;
            int neighbourRight  = (CELL_GRID_SIZE-1==x) ? 0 : x+1;
            int neighbourAbove  = (0==y) ? CELL_GRID_SIZE-1 : y-1;
            int neighbourBelow  = (CELL_GRID_SIZE-1==y) ? 0 : y+1;

            gUniverse[x][y].NeighbourCells[0] = &gUniverse[neighbourLeft][neighbourAbove];
            gUniverse[x][y].NeighbourCells[1] = &gUniverse[x][neighbourAbove];
            gUniverse[x][y].NeighbourCells[2] = &gUniverse[neighbourRight][neighbourAbove];
            gUniverse[x][y].NeighbourCells[3] = &gUniverse[neighbourLeft][y];
            gUniverse[x][y].NeighbourCells[4] = &gUniverse[neighbourRight][y];
            gUniverse[x][y].NeighbourCells[5] = &gUniverse[neighbourLeft][neighbourBelow];
            gUniverse[x][y].NeighbourCells[6] = &gUniverse[x][neighbourBelow];
            gUniverse[x][y].NeighbourCells[7] = &gUniverse[neighbourRight][neighbourBelow];
        }
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  ProcessCellGrid
//
//  Performs an iteration on the cell grid. Each cell will either stay or swap its position with another random cell
//  based on how many neighbouring cells are of the same or different colour.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    ProcessCellGrid
    (
        void
    )
{
    int x;
    int y;
    int i;

    gNumCellsToMove = 0;

    // Now determine if a cell wants to swap
    for( y=0; y<CELL_GRID_SIZE; y++ )
    {
        for( x=0; x<CELL_GRID_SIZE; x++ )
        {
            uint8_t value;
            int numSameColour = 0;
            int moveThreshold;

            // Count how many neighbours are of same colour
            for( i=0; i<8; i++ )
            {
                if( gUniverse[x][y].NeighbourCells[i]->CellType == gUniverse[x][y].CellType )
                {
                    numSameColour += 1;
                }
            }

            moveThreshold = gMovingThreshold[numSameColour];

            Rc4Output( &gRc4Context, &value, sizeof(value) );

            if( (int)value > moveThreshold )
            {
                // This cell wants to move, so add it to the list of cells wanting to relocate
                gCellsToMove[gNumCellsToMove] = &gUniverse[x][y];
                gNumCellsToMove += 1;
            }
        }
    }

    // Swap the cells that want to move
    for( i=0; i<gNumCellsToMove/2; i++ )
    {
        int temp;
        temp = gCellsToMove[i]->CellType;
        gCellsToMove[i]->CellType = gCellsToMove[gNumCellsToMove-1-i]->CellType;
        gCellsToMove[gNumCellsToMove-1-i]->CellType = temp;
    }

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  DrawCells
//
//  Draws the cells in the cell grid
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    DrawCells
    (
        void
    )
{
    int x;
    int y;
    double size = 2.0 / (double)CELL_GRID_SIZE;

    for( y=0; y<CELL_GRID_SIZE; y++ )
    {
        for( x=0; x<CELL_GRID_SIZE; x++ )
        {
            double  posX = (2.0 * (double)x / CELL_GRID_SIZE) - 1.0;
            double  posY = (2.0 * (double)y / CELL_GRID_SIZE) - 1.0;

            // Draw cell
            glBegin( GL_POLYGON );
            glColor3d( CellColourR[gUniverse[x][y].CellType], CellColourG[gUniverse[x][y].CellType], CellColourB[gUniverse[x][y].CellType] );

            glVertex3d( posX, posY, 0.0 );
            glVertex3d( posX+size, posY, 0.0 );
            glVertex3d( posX+size, posY+size, 0.0 );
            glVertex3d( posX, posY+size, 0.0 );

            glEnd( );
        }
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  DrawFunction
//
//  Called by LibOpenGL
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    DrawFunction
    (
        void
    )
{
	glClearColor( 0.0f, 0.0f, 0.0f, 0.0f );
	glClear( GL_COLOR_BUFFER_BIT );

    ProcessCellGrid( );
    DrawCells( );
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  main
//
//  Entry point
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int
    main
    (
        void
    )
{
    InitialUniverseFill( );

    OpenGLRun( CELL_GRID_SIZE*2, CELL_GRID_SIZE*2, "Racist Cells", DrawFunction, 50 );

    return 0;
}
