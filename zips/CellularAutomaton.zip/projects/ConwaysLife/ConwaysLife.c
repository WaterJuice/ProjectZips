///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  ConwaysLife
//
//  The classic Conway's Life cell automation program using OpenGL
//
//  This is free and unencumbered software released into the public domain - July 2013 waterjuice.org
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  IMPORTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <sys/timeb.h>
#include <stdio.h>
#include <memory.h>
#include "LibOpenGL.h"
#include "LibRc4.h"

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  CONSTANTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define CELL_GRID_SIZE     380

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  TYPES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
typedef struct _Cell
{
    bool            CellExists;
    struct _Cell*   NeighbourCells[8];
    int             NumNeighbours;
} Cell;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  GLOBALS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static Cell     gUniverse [CELL_GRID_SIZE][CELL_GRID_SIZE];

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SeedStreamWithRandom
//
//  Initialises an RC4 stream with a random key. Note this has a very poor source of entropy, this should not be
//  used in cryptography.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void
    SeedStreamWithRandom
    (
        Rc4Context*         Context
    )
{
    struct
    {
        struct timeb        time;
        void*               address;
    } seedValues;

    ftime( &seedValues.time );
    seedValues.address = Context;

    Rc4Initialise( Context, &seedValues, sizeof(seedValues), 0 );
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  InitialUniverseFill
//
//  Fills the universe with random cells. Also sets up the neighbour pointers to point to the correct cells
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    InitialUniverseFill
    (
        void
    )
{
    Rc4Context  rc4Context;
    int x;
    int y;

    SeedStreamWithRandom( &rc4Context );

    // Wipe universe array
    memset( gUniverse, 0, sizeof(gUniverse) );

    // Populate cells with a random distribution
    for( y=0; y<CELL_GRID_SIZE; y++ )
    {
        for( x=0; x<CELL_GRID_SIZE; x++ )
        {
            uint8_t value;
            Rc4Output( &rc4Context, &value, sizeof(value) );

            if( value > 128 )
            {
                gUniverse[x][y].CellExists = true;
            }
        }
    }

    // Create neighbour pointers
    for( y=0; y<CELL_GRID_SIZE; y++ )
    {
        for( x=0; x<CELL_GRID_SIZE; x++ )
        {
            int neighbourLeft   = (0==x) ? CELL_GRID_SIZE-1 : x-1;
            int neighbourRight  = (CELL_GRID_SIZE-1==x) ? 0 : x+1;
            int neighbourAbove  = (0==y) ? CELL_GRID_SIZE-1 : y-1;
            int neighbourBelow  = (CELL_GRID_SIZE-1==y) ? 0 : y+1;

            gUniverse[x][y].NeighbourCells[0] = &gUniverse[neighbourLeft][neighbourAbove];
            gUniverse[x][y].NeighbourCells[1] = &gUniverse[x][neighbourAbove];
            gUniverse[x][y].NeighbourCells[2] = &gUniverse[neighbourRight][neighbourAbove];
            gUniverse[x][y].NeighbourCells[3] = &gUniverse[neighbourLeft][y];
            gUniverse[x][y].NeighbourCells[4] = &gUniverse[neighbourRight][y];
            gUniverse[x][y].NeighbourCells[5] = &gUniverse[neighbourLeft][neighbourBelow];
            gUniverse[x][y].NeighbourCells[6] = &gUniverse[x][neighbourBelow];
            gUniverse[x][y].NeighbourCells[7] = &gUniverse[neighbourRight][neighbourBelow];
        }
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  CountNeighbours
//
//  Counts the neighbours in the cell universe and fills in the NumNeighbours field for each cell
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    CountNeighbours
    (
        void
    )
{
    int x;
    int y;

    // Erase current count values
    for( y=0; y<CELL_GRID_SIZE; y++ )
    {
        for( x=0; x<CELL_GRID_SIZE; x++ )
        {
            gUniverse[x][y].NumNeighbours = 0;
        }
    }

    // For each cell that exists add 1 to the neighbour count of all its neighbours.
    for( y=0; y<CELL_GRID_SIZE; y++ )
    {
        for( x=0; x<CELL_GRID_SIZE; x++ )
        {
            if( gUniverse[x][y].CellExists )
            {
                int i;
                for( i=0; i<8; i++ )
                {
                    gUniverse[x][y].NeighbourCells[i]->NumNeighbours += 1;
                }
            }
        }
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  ProcessCellGrid
//
//  Performs an iteration on the cell grid. Each cell will be created or destroyed based on Conway's life rules.
//  Rules:
//      1) A cell with exactly 3 neighbours will be created (or stay alive if already there)
//      2) An existing cell with exactly 2 neighbours will stay alive
//      3) An existing cell with less than 2 neighbours or more than 3 neighbours will be destroyed.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    ProcessCellGrid
    (
        void
    )
{
    int x;
    int y;

    // First count the neighbours for each cell
    CountNeighbours( );

    // Now apply the rules
    for( y=0; y<CELL_GRID_SIZE; y++ )
    {
        for( x=0; x<CELL_GRID_SIZE; x++ )
        {
            if( gUniverse[x][y].CellExists )
            {
                if( gUniverse[x][y].NumNeighbours < 2  ||  gUniverse[x][y].NumNeighbours > 3 )
                {
                    // Destroy cell
                    gUniverse[x][y].CellExists = false;
                }
            }
            else
            {
                if( 3 == gUniverse[x][y].NumNeighbours )
                {
                    // Create cell
                    gUniverse[x][y].CellExists = true;
                }
            }
        }
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  DrawCells
//
//  Draws the cells in the cell grid
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    DrawCells
    (
        void
    )
{
    int x;
    int y;
    double size = 2.0 / (double)CELL_GRID_SIZE;

    for( y=0; y<CELL_GRID_SIZE; y++ )
    {
        for( x=0; x<CELL_GRID_SIZE; x++ )
        {
            if( gUniverse[x][y].CellExists )
            {
                double  posX = (2.0 * (double)x / CELL_GRID_SIZE) - 1.0;
                double  posY = (2.0 * (double)y / CELL_GRID_SIZE) - 1.0;
                // Draw cell
                glBegin( GL_POLYGON );

                glVertex3d( posX, posY, 0.0 );
                glVertex3d( posX+size, posY, 0.0 );
                glVertex3d( posX+size, posY+size, 0.0 );
                glVertex3d( posX, posY+size, 0.0 );

                glEnd( );

            }
        }
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  DrawFunction
//
//  Called by LibOpenGL
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    DrawFunction
    (
        void
    )
{
	glClearColor( 0.0f, 0.0f, 0.0f, 0.0f );
	glClear( GL_COLOR_BUFFER_BIT );
    glColor3d( 0.0, 1.0, 0.0 );

    ProcessCellGrid( );
    DrawCells( );
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  main
//
//  Entry point
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int
    main
    (
        void
    )
{
    InitialUniverseFill( );

    OpenGLRun( CELL_GRID_SIZE*2, CELL_GRID_SIZE*2, "Conway's Life", DrawFunction, 60 );

    return 0;
}
