Cellular Automaton
==================

This contains two examples of Celluar Automaton.

1. Conway's Life
2. Racist Cells


Conway's Life
-------------

An existing cell remains alive if it is surrounded by 2 or 3 neighbouring 
cells, otherwise it dies and is removed.
A cell will be created if its position is surrounded by exactly 3
neighbouring cells.

Racist Cells
------------

Each position in the "universe" is filled with a cell from one of 5 colours.
There is equal distribution of the cells. At each iteration a cell may choose
to move by swapping with another cell somewhere in the universe that also
wants to move. The probability of a cell moving is lower when it is surrounded
by more cells of its same colour.

-------------------------------------------------------------------------------

The makefile is for gnu make and works on Linux, OSX, Cygwin.
It also works on Windows with VSS if cygwin (or some other gnu make) is
setup and the environment has been setup correctly. Use the batch files 
in Visual Studio to bring up a command prompt with the appropraite build 
environment.

A Visual Studio 2010 solution file also exists, which has project files.
This can be used instead of the makefile for VS2010.

*Created August 2013*             

License
=======

This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <http://unlicense.org/>

