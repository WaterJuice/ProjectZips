///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  This H file create a function that performs a speed test on a specified hash. This uses #defines to create the
//  name of the function and to select the hash functions. This is to avoid losing any speed due to passing variable
//  function pointers.
//
//  This file should be included at the point where the function is to be created. Set the following defines before
//  including.
//
//  SET_FUNCTION_NAME       - The name of the function (eg Sha1SpeedTest)
//  SET_HASH_NAME           - The name of the hash (eg "SHA1")
//  SET_HASH_TYPE           - The type of the output hash (eg SHA1_HASH)
//  SET_HASH_CONTEXT        - The context of the hash (eg Sha1Context)
//  SET_HASH_INIT_FUNC      - The Initialise function (eg Sha1Initialise)
//  SET_HASH_UPDATE_FUNC    - The Update function (eg Sha1Update)
//  SET_HASH_FINALISE_FUNC  - The Finalise function (eg Sha1Finalise)
//  SET_BENCHMARK_ITER_SMALL- Number of iterations for small hash
//  SET_BENCHMARK_ITER_LARGE- Number of iterations for large hash
//  SET_BENCHMARK_DATA_SIZE - Size used in Large hash iterations
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Uncomment to show the benchmark values
//#define SHOW_BENCHMARKS

static
void
    SET_FUNCTION_NAME
    (
        void
    )
{
    uint64_t                startTime;
    uint64_t                endTime;
    uint32_t                dataSize;
    uint32_t                i;
    uint8_t*                buffer;
    SET_HASH_TYPE           hash;
    SET_HASH_CONTEXT        context;
    uint32_t                iterations;
    double                  timePassed;
    double                  hashRate;
    double                  dataRate;
    double                  benchMark;
    uint8_t                 smallBuffer [100];
    
    printf( "%-12s ", SET_HASH_NAME );

    // Do small iterations
    dataSize = 32;
    iterations = SET_BENCHMARK_ITER_SMALL;
    // Doesn't matter what the data is, so just fill it up with numbers
    for( i=0; i<sizeof(smallBuffer); i++ )
    {
        smallBuffer[i] = (uint8_t)(i + 5);
    }

    startTime = GetMilliSecondTime( );
    for( i=0; i<iterations; i++ )
    {
        SET_HASH_INIT_FUNC( &context );
        SET_HASH_UPDATE_FUNC( &context, smallBuffer, dataSize );
        SET_HASH_FINALISE_FUNC( &context, &hash );
    }
    endTime = GetMilliSecondTime( );
    timePassed = (double) (endTime - startTime);
    hashRate = ( 1000.0 * ((double)iterations) / timePassed ) / 1000000.0;
    benchMark = 1000.0 / ( timePassed );
    printf( " %6.3f MHashes/s", hashRate );
#ifdef SHOW_BENCHMARKS
    printf( " %7.4f secs", timePassed/1000.0 );
    printf( " (%3.0f%% BenchMark)", benchMark*100.0 );
#endif

    // Do normal buffer
    dataSize = SET_BENCHMARK_DATA_SIZE;
    iterations = 100*1024;
    buffer = (uint8_t*) malloc( dataSize );
    if( buffer )
    {
        for( i=0; i<sizeof(buffer); i++ )
        {
            smallBuffer[i] = (uint8_t)(i + 7);
        }

        startTime = GetMilliSecondTime( );
        for( i=0; i<iterations; i++ )
        {
            SET_HASH_INIT_FUNC( &context );
            SET_HASH_UPDATE_FUNC( &context, buffer, dataSize );
            SET_HASH_FINALISE_FUNC( &context, &hash );
        }
        endTime = GetMilliSecondTime( );
        timePassed = (double)( endTime - startTime );
        dataRate = ( ( 1000.0 * ((double)iterations) * ((double)dataSize) ) / timePassed ) / ( 1024.0*1024.0);
        benchMark = 1000.0 / ( timePassed );
        printf( "  " );
        printf( " %6.2f MBytes/s", dataRate );
#ifdef SHOW_BENCHMARKS
        printf( " %7.4f secs", timePassed/1000.0 );
        printf( " (%3.0f%% BenchMark)", benchMark*100.0 );
#endif

        free( buffer );
    }
    else
    {
        printf( "MEMORY FAIL\n" );
    }

    printf( "\n" );
}

#undef SET_FUNCTION_NAME     
#undef SET_HASH_NAME         
#undef SET_HASH_TYPE         
#undef SET_HASH_CONTEXT      
#undef SET_HASH_INIT_FUNC    
#undef SET_HASH_UPDATE_FUNC  
#undef SET_HASH_FINALISE_FUNC
#undef SET_BENCHMARK_ITER_SMALL
#undef SET_BENCHMARK_DATA_SIZE 
