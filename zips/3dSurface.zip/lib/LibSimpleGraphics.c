///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  LibSimpleGraphics
//
//  This library provides a very simple cross platform graphics library. For Windows it uses the Win32 graphics API.
//  For OSX and Linux it uses OpenGL with GLUT.
//
//  Version 0.1.0 - This code is still in development and should not be considered complete or stable
//
//  This is free and unencumbered software released into the public domain - July 2013 waterjuice.org
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#if defined( _WIN32 ) || defined( __CYGWIN__ )
    #define USE_WIN32
#else
    #define USE_OPENGL
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  IMPORTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "LibSimpleGraphics.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>

#ifdef USE_OPENGL
    #ifdef __APPLE__
        #include <GLUT/glut.h>
        #include <OpenGL/gl.h>
        #include <OpenGL/glu.h>
    #else
        #include <GL/freeglut.h>
        #include <GL/gl.h>
        #include <GL/glu.h>
    #endif
#else
    #include <Windows.h>
#endif

#if defined( _WIN32 )
    #include <Windows.h>
#else
    #include <pthread.h>
    #include <sched.h>
    #include <sys/resource.h>
    #include <unistd.h>
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SETTINGS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef _WIN32
    #pragma warning( disable : 4200 )   // Remove warning about nonstandard use of variable size array in struct
    #pragma warning( disable : 4204 )   // Remove warning about nonstandard non-constant aggregate initializer
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  CONSTANTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define RESOLUTION_X_MIN        32
#define RESOLUTION_X_MAX        1024
#define RESOLUTION_Y_MIN        32
#define RESOLUTION_Y_MAX        1024

#define MAX_POINTS              4

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  TYPES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Internal type used to represent a point
typedef struct
{
    #ifdef USE_OPENGL
        float   X;
        float   Y;
    #else
        int     X;
        int     Y;
    #endif
} SgInternalPoint;

// Internal type used to represent a colour
typedef struct
{
    #ifdef USE_OPENGL
        float       R;
        float       G;
        float       B;
    #else
        COLORREF    ColourRef;
    #endif
} SgInternalColour;

typedef struct
{
    SgThreadStartFunction   UserFunction;
    void*                   UserContext;
} NewUserThreadParams;

typedef uint8_t  OPERATION;

#define OPERATION_LINE              1
#define OPERATION_POLYLINE          2
#define OPERATION_POLYGON           3

typedef struct _DrawOperations
{
    struct _DrawOperations* Next;

    OPERATION               Operation;

    SgInternalColour        Colour;
    int                     NumPoints;
    SgInternalPoint         Points [];
} DrawOperations;

typedef volatile long          SPINLOCK;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  GLOBALS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static SPINLOCK             gModuleSpinLock = 0;
static bool                 gModuleInitialised = false;

static int                  gWindowResX = 0;
static int                  gWindowResY = 0;
static SPINLOCK             gThreadSync = 0;
static bool                 gWindowCreateSuccess;
static volatile bool        gSignalCloseWindow = false;

static SPINLOCK             gDrawListSpinLock = 0;
static DrawOperations*      gDrawListHead = NULL;
static DrawOperations*      gDrawListTail = NULL;    

#ifdef USE_WIN32
    static HWND                 gWindowHandle = NULL;
    static DrawOperations*      gPendingDrawListHead = NULL;
    static bool                 gPerformFullRedraw = false;
    static bool                 gClearWindow = false;
#else
    static bool                 gForceRedraw = false;
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  INTERNAL FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SpinLockAcquire
//
//  Acquires the thread spinlock. This will wait (spin) until the lock is acquired. Use this to protect a resource
//  from multi thread access. Do not hold the spinlock for long periods of time.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void
    SpinLockAcquire
    (
        SPINLOCK*       SpinLockPtr
    )
{
#if defined( _WIN32 )
    while( InterlockedCompareExchange( SpinLockPtr, 1, 0 ) )
    {
        Sleep( 0 );
    }
#else
    while( !__sync_bool_compare_and_swap( SpinLockPtr, 0, 1 ) )
    {
#if defined( __APPLE__ )
        pthread_yield_np( );
#else
        sched_yield( );
#endif
    }
#endif
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SpinLockRelease
//
//  Releases the thread spinlock. Do not call this unless you have acquired the spinlock.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    SpinLockRelease
    (
        SPINLOCK*       SpinLockPtr
    )
{
    *SpinLockPtr = 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  LaunchNewThread
//
//  Launches a new thread. Passes the pointer Context through to the new thread function.
//  Returns true on success or false on failure
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool
    LaunchNewThread
    (
        SgThreadStartFunction   StartFunction,
        void*                   Context
    )
{
#if defined( _WIN32 )
    HANDLE                          threadHandle = 0;
#else
    pthread_t                       threadHandle = 0;
    pthread_attr_t                  attributes;
    int                             errors;
#endif
    uint32_t                        success = 0;

#if defined( _WIN32 )
    threadHandle = CreateThread( NULL, 0, (LPTHREAD_START_ROUTINE)StartFunction, Context, 0, NULL );
    if( NULL != threadHandle )
#else
    pthread_attr_init( &attributes );
    errors = pthread_create( &threadHandle, &attributes, (void*)StartFunction, Context );
    if( 0 == errors )
#endif
    {
       // Close the handle as we do not need it anymore. Thread has been created
#if defined( _WIN32 )
        CloseHandle( threadHandle );
#else
        pthread_attr_destroy( &attributes );
#endif
        success = 1;
    }
    else
    {
        // Failed to create thread
        success = 0;
    }

    return success;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  WIN32 PROCESSING FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef USE_WIN32

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  ProcessOperationWin32
//
//  Processes a drawing operation
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void
    ProcessOperationWin32
    (
        HDC                 hdc,
        DrawOperations*     DrawOp
    )
{
    switch( DrawOp->Operation )
    {
    case OPERATION_LINE:
        {
            HPEN pen = CreatePen( PS_SOLID, 1, DrawOp->Colour.ColourRef );

            SelectObject( hdc, pen );
            MoveToEx( hdc, DrawOp->Points[0].X, DrawOp->Points[0].Y, NULL );
            LineTo( hdc, DrawOp->Points[1].X, DrawOp->Points[1].Y );

            DeleteObject( pen );
        }
        break;
    case OPERATION_POLYLINE:
        {
            HPEN pen = CreatePen( PS_SOLID, 1, DrawOp->Colour.ColourRef );
            POINT corners[MAX_POINTS+1];
            int i;

            SelectObject( hdc, pen );
            for( i=0; i<DrawOp->NumPoints; i++ )
            {
                corners[i].x = DrawOp->Points[i].X;
                corners[i].y = DrawOp->Points[i].Y;
            }
            corners[DrawOp->NumPoints].x = DrawOp->Points[0].X;
            corners[DrawOp->NumPoints].y = DrawOp->Points[0].Y;
            Polyline( hdc, corners, DrawOp->NumPoints+1 );

            DeleteObject( pen );
        }
        break;
    case OPERATION_POLYGON:
        {
            HPEN pen = CreatePen( PS_SOLID, 1, DrawOp->Colour.ColourRef );
            HBRUSH brush = CreateSolidBrush( DrawOp->Colour.ColourRef );
            POINT corners[MAX_POINTS+1];
            int i;

            SelectObject( hdc, pen );
            SelectObject( hdc, brush );
            for( i=0; i<DrawOp->NumPoints; i++ )
            {
                corners[i].x = DrawOp->Points[i].X;
                corners[i].y = DrawOp->Points[i].Y;
            }
            Polygon( hdc, corners, DrawOp->NumPoints );

            DeleteObject( pen );
            DeleteObject( brush );
        }
        break;
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  ProcessOperationsWin32
//
//  Processes any draw operations. This function is called by the message loop when a timer event is triggered
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void
    ProcessOperationsWin32
    (
        HWND    hWnd
    )
{
    DrawOperations*     drawOperations;

    SpinLockAcquire( &gDrawListSpinLock );
    {
        if( gPerformFullRedraw )
        {
            drawOperations = gDrawListHead;
            gPerformFullRedraw = false;
        }
        else
        {
            drawOperations = gPendingDrawListHead;
        }

        if( gClearWindow )
        {
            RECT    fullRect = {0};
            fullRect.right = gWindowResX;
            fullRect.bottom = gWindowResY;
            InvalidateRect( hWnd, &fullRect, TRUE );
            gClearWindow = false;
        }

        if( drawOperations )
        {
            HDC         hdc = GetDC( hWnd );

            while( drawOperations )
            {
                ProcessOperationWin32( hdc, drawOperations );
                drawOperations=drawOperations->Next;
            }

            ReleaseDC( hWnd, hdc );

            // Reset pending list pointer
            gPendingDrawListHead = NULL;
        }
    }
    SpinLockRelease( &gDrawListSpinLock );
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  WndProc
//
//  Windows Message Handler
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
LRESULT 
CALLBACK 
    WndProc
    (
        HWND    hWnd,
        UINT    message,
        WPARAM  wParam,
        LPARAM  lParam
    )
{
    switch (message)
    {
    case WM_CREATE:
        // Create a timer event so we get polled regularly.
        SetTimer( hWnd, 1, 10, NULL );
    case WM_TIMER:
        ProcessOperationsWin32( hWnd );
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
        break;
    }

    return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  CreateGraphicsWindowWin32
//
//  Creates the graphics window.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
bool
    CreateGraphicsWindowWin32
    (
        int     ResolutionX,
        int     ResolutionY,
        char*   Title
   )
{
    bool success = false;
    WNDCLASSEX wcex;
    HWND hWnd;
    CHAR className[] = "SimpleGraphicsWin32";

    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = GetModuleHandle(NULL);
    wcex.hIcon          = NULL;
    wcex.hCursor        = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(INT_PTR)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = NULL;
    wcex.lpszClassName  = className;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE((INT_PTR)IDI_APPLICATION));
    
    if( RegisterClassEx(&wcex) )
    {
        // Adjust rectangle to be size of draw area plus window frames
        RECT wr = {0, 0, ResolutionX, ResolutionY};
        AdjustWindowRect( &wr, WS_OVERLAPPEDWINDOW, FALSE ); 

        // Create the window
        hWnd = CreateWindow(
            className,
            Title,
            WS_OVERLAPPEDWINDOW,
            CW_USEDEFAULT, CW_USEDEFAULT,
            wr.right - wr.left,
            wr.bottom - wr.top,
            NULL,
            NULL,
            GetModuleHandle(NULL),
            NULL
        );

        if( hWnd )
        {
            ShowWindow( hWnd, SW_SHOW );
            UpdateWindow( hWnd );
            gWindowHandle = hWnd;
            success = true;
        }
        else
        {
            // CreateWindow failed
            success = false;
        }
    }
    else
    {
        // Failed to register class
        success = false;
    }

    return success;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  IterateMessageLoopWin32
//
//  Performs an iteration of the Windows Message loop
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void
    IterateMessageLoopWin32
    (
        void 
    )
{
    MSG msg;

    GetMessage( &msg, gWindowHandle, 0, 0 );
    TranslateMessage( &msg);
    DispatchMessage( &msg);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#endif // USE_WIN32

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  OPENGL PRIVATE FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef USE_OPENGL

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  ProcessOperationOpenGL
//
//  Processes a drawing operation
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void
    ProcessOperationOpenGL
    (
        DrawOperations*     DrawOp
    )
{
    switch( DrawOp->Operation )
    {
    case OPERATION_LINE:
        {
	        glColor3f( DrawOp->Colour.R, DrawOp->Colour.G, DrawOp->Colour.B );
	        glBegin( GL_LINES );
	        glVertex2f( DrawOp->Points[0].X, DrawOp->Points[0].Y );
	        glVertex2f( DrawOp->Points[1].X, DrawOp->Points[1].Y );
	        glEnd( );
        }
        break;
    case OPERATION_POLYLINE:
        {
            int i;
	        glColor3f( DrawOp->Colour.R, DrawOp->Colour.G, DrawOp->Colour.B );
	        glBegin( GL_LINE_LOOP );
            for( i=0; i<DrawOp->NumPoints; i++ )
            {
	            glVertex2f( DrawOp->Points[i].X, DrawOp->Points[i].Y );
            }
	        glEnd( );
        }
        break;
    case OPERATION_POLYGON:
        {
            int i;
	        glColor3f( DrawOp->Colour.R, DrawOp->Colour.G, DrawOp->Colour.B );
	        glBegin( GL_POLYGON );
            for( i=0; i<DrawOp->NumPoints; i++ )
            {
	            glVertex2f( DrawOp->Points[i].X, DrawOp->Points[i].Y );
            }
	        glEnd( );
        }
        break;
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  ProcessAllOperations
//
//  Processes all drawing operations. This function is called by the display function
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void
    ProcessAllOperations
    (
        void
    )
{
    DrawOperations*     drawOperations;

    SpinLockAcquire( &gDrawListSpinLock );
    {
        //if( gPerformFullRedraw )
        //{
            drawOperations = gDrawListHead;
//            gPerformFullRedraw = false;
        //}
        //else
        //{
        //    drawOperations = gPendingDrawListHead;
        //}

        // Now process list
        if( drawOperations )
        {
            while( drawOperations )
            {
                ProcessOperationOpenGL( drawOperations );
                drawOperations=drawOperations->Next;
            }

//            gPendingDrawListHead = NULL;
        }
    }
    SpinLockRelease( &gDrawListSpinLock );
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Display
//
//  Called by OpenGL to perform the drawing
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void
    Display
    (
        void
    )
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    ProcessAllOperations( );

    glutSwapBuffers();
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  TimerFunc
//
//  Called by OpenGL in as the timer function
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void
    TimerFunc
    (
        int     Unused
    )
{
    bool redraw = false;
    (void) Unused;

    SpinLockAcquire( &gDrawListSpinLock );
    {
        if( gForceRedraw )
        {
            redraw = true;
            gForceRedraw = false;
        }
    }
    SpinLockRelease( &gDrawListSpinLock );

    if( redraw )
    {
        Display( );
    }

    // Reset our timer to get triggered again
    glutTimerFunc( 10, TimerFunc, 0 );
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Reshape
//
//  Called by OpenGL to every time a window is resized
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void 
    Reshape
    (
        int     Width,
        int     Height
    )
{
    // Force window back to the original size
//    glutReshapeWindow( gWindowResX, gWindowResY );
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  CreateGraphicsWindowOpenGL
//
//  Creates the graphics window.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
bool
    CreateGraphicsWindowOpenGL
    (
        int     ResolutionX,        // [in]
        int     ResolutionY,        // [in]
        char*   Title               // [in]
    )
{
    char* argv[] = { "Hello" };
    int argc = 1;

    // Initializes glut
    glutInit( &argc, argv );

    // Sets up a double buffer with RGBA components
    glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGB );
                                    
    // Sets the window size
    glutInitWindowSize( ResolutionX, ResolutionY );

    // Sets the window position to the upper left
    glutInitWindowPosition(0, 0);

    // Creates a window using internal glut functionality
    glutCreateWindow( Title );

    // passes reshape and display functions to the OpenGL machine for callback
    glutReshapeFunc( Reshape );
    glutDisplayFunc( Display );
    glutTimerFunc( 10, TimerFunc, 0 );

    glClearColor(1.0, 1.0, 1.0, 0.0);
    glEnable(GL_DEPTH_TEST);
    glShadeModel(GL_SMOOTH);

    return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#endif //USE_OPENGL

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  COMMON PRIVATE FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  NewUserThreadFunction
//
//  This function is run in its own thread. It creates a window and then processes the message loop of the window
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void
    NewUserThreadFunction
    (
        void*       Parameters
    )
{
    NewUserThreadParams* params = (NewUserThreadParams*)Parameters;

    // Execute user function
    params->UserFunction( params->UserContext );

    // Now signal that function has ended, we want the main thread to close window and return
    gSignalCloseWindow = true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  AddOperationToList
//
//  Adds a draw operation to the linked list
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
void
    AddOperationToList
    (
        DrawOperations*     Operation
    )
{
    SpinLockAcquire( &gDrawListSpinLock );
    {
        Operation->Next = NULL;
        if( gDrawListTail )
        {
            gDrawListTail->Next = Operation;
        }
        else
        {
            gDrawListHead = Operation;
        }
        gDrawListTail = Operation;

#ifdef USE_WIN32
        if( NULL == gPendingDrawListHead )
        {
            // There were no pending operations, so this new one becomes it
            gPendingDrawListHead = Operation;
        }
#else
        gForceRedraw = true;
#endif
    }
    SpinLockRelease( &gDrawListSpinLock );
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  AllocOperation
//
//  Allocates an operation with specified number of points
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static
DrawOperations*
    AllocOperation
    (
        int     NumberOfPoints
    )
{
    DrawOperations* operation;

    operation = (DrawOperations*) malloc( sizeof(DrawOperations) + sizeof(SgInternalPoint)*NumberOfPoints );
    if( operation )
    {
        operation->NumPoints = NumberOfPoints;
    }
    return operation;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  COLOUR AND COORDINATE CONVERSION MACROS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef USE_WIN32
    #define DefinePoint( PointRef, Pos )                                            \
        PointRef.X = (Pos.X);                                                       \
        PointRef.Y = (Pos.Y);
    #define DefineColour( Ref, Colour )                                             \
        Ref.ColourRef = RGB( (Colour.R), (Colour.G), (Colour.B) )
#else
    #define DefinePoint( PointRef, Pos )                                            \
        PointRef.X = 2.0 * ((float)(Pos.X)+0.5) / (float)gWindowResX - 1.0;         \
        PointRef.Y = 0.0 - (2.0 * ((float)(Pos.Y)+0.5) / (float)gWindowResY - 1.0);
    #define DefineColour( Ref, Colour )                                             \
        Ref.R = (float)(Colour.R) / 255.0;                                          \
        Ref.G = (float)(Colour.G) / 255.0;                                          \
        Ref.B = (float)(Colour.B) / 255.0;
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  FUNCTION REDIRECTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef USE_WIN32
    #define CreateGraphicsWindow( X, Y, Title )        CreateGraphicsWindowWin32( (X), (Y), (Title) )
    #define IterateMessageLoop( )                      IterateMessageLoopWin32( )
    #define CloseGraphicsWindow( )                     CloseWindow( gWindowHandle );
#else
    #define CreateGraphicsWindow( X, Y, Title )        CreateGraphicsWindowOpenGL( (X), (Y), (Title) )
    #ifdef __APPLE__
        #define IterateMessageLoop( )                      glutCheckLoop( )
    #else
        #define IterateMessageLoop( )                      glutMainLoopEvent( )
    #endif
    #define CloseGraphicsWindow( )
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  PUBLIC FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SimpleGraphicsRun
//
//  Starts the SimpleGraphics module. This will create a window of the specified size which will be used for all
//  subsequent drawing operations. Due to requirements in some OSes that the main thread is used, this will create
//  a new thread and pass execution to the supplied Function. This function will not return until after the thread
//  function ends, at which point it will then close the window. This will return true if successful, false if an 
//  error occurred.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool
    SimpleGraphicsRun
    (
        uint16_t                ResolutionX,    // [in]
        uint16_t                ResolutionY,    // [in]
        char*                   Title,          // [in]
        SgThreadStartFunction   Function,       // [in]
        void*                   FunctionContext // [in]
    )
{
    bool    success = false;

    if(     ResolutionX >= RESOLUTION_X_MIN
        &&  ResolutionX <= RESOLUTION_X_MAX
        &&  ResolutionY >= RESOLUTION_Y_MIN
        &&  ResolutionY <= RESOLUTION_Y_MAX
        &&  NULL != Title
        &&  NULL != Function )
    {
        SpinLockAcquire( &gModuleSpinLock );
        {
            if( !gModuleInitialised )
            {
                gWindowResX = ResolutionX;
                gWindowResY = ResolutionY;

                success = CreateGraphicsWindow( gWindowResX, gWindowResY, Title );
                if( success )
                {
                    // Launch user thread
                    NewUserThreadParams threadParams = {0};

                    threadParams.UserFunction = Function;
                    threadParams.UserContext = FunctionContext;

                    gSignalCloseWindow = false;
                    success = LaunchNewThread( NewUserThreadFunction, &threadParams );
                    if( success )
                    {
                        // Ready to run the message loop
                    }
                    else
                    {
                        // Failed to create thread
                    }
                }
                else
                {
                    // Failed to create window
                    // Indicate failure and release the lock
                    gWindowCreateSuccess = false;
                    SpinLockRelease( &gThreadSync );
                }
            }
            else
            {
                // Already started
                success = false;
            }
        }
        SpinLockRelease( &gModuleSpinLock );

        if( success )
        {
            // Run Message loop
            while( !gSignalCloseWindow )
            {
                IterateMessageLoop( );
                #ifdef USE_OPENGL
                {
                    // Pause for 10 milliseconds (which is when our timer function is to be triggered)
                    // otherwise CPU usage goes high.
                    usleep( 10000 );
                }
                #endif
            }
                        
            // Thread has closed, so we need to close window and return
            CloseGraphicsWindow( );
        }
    }
    else
    {
        // Resolution values out of range or other invalid parameters
        success = false;
    }

    return success;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SgRGB
//
//  Returns a SgColour type from seperate red, green, and blue values
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
SgColour
    __SgRGB
    (
        uint8_t     Red,
        uint8_t     Green,
        uint8_t     Blue
    )
{
    SgColour colour;
    
    colour.R = Red;
    colour.G = Green;
    colour.B = Blue;

    return colour;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SgXY
//
//  Returns a SgPoint type from seperate X and Y coordinates
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
SgPoint
    __SgXY
    (
        uint16_t    X,
        uint16_t    Y
    )
{
    SgPoint point;
    
    point.X = X;
    point.Y = Y;

    return point;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SgClear
//
//  Removes all objects from window
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    SgClear
    (
        void
    )
{
    DrawOperations*     operation;

    // Take list from global list
    SpinLockAcquire( &gDrawListSpinLock );
    {
        operation = gDrawListHead;
        gDrawListHead = NULL;
        gDrawListTail = NULL;
#ifdef USE_WIN32
        gPendingDrawListHead = NULL;
        gPerformFullRedraw = true;
        gClearWindow = true;
#else
        gForceRedraw = true;
#endif
    }
    SpinLockRelease( &gDrawListSpinLock );

    // Deallocate all entries
    while( operation )
    {
        DrawOperations* next = operation->Next;

        free( operation );
        operation = next;
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SgDrawLine
//
//  Draws a line between two points in the specified colour
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool
    SgDrawLine
    (
        SgPoint     Start,
        SgPoint     End,
        SgColour    Colour
    )
{
    DrawOperations*     newOperation;
    bool                success = false;

    newOperation = AllocOperation( 2 );

    if( newOperation )
    {
        // Build up operation
        newOperation->Operation = OPERATION_LINE;
        DefinePoint( newOperation->Points[0], Start );
        DefinePoint( newOperation->Points[1], End );
        DefineColour( newOperation->Colour, Colour );

        AddOperationToList( newOperation );
    }
    else
    {
        // Unable to allocate memory
        success = false;
    }

    return success;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SgDrawRectangle
//
//  Draws an outline of a rectangle specified by upper left and lower right corner points in the specified colour. 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool
    SgDrawRectangle
    (
        SgPoint     UpperLeft,
        SgPoint     LowerRight,
        SgColour    Colour
    )
{
    DrawOperations*     newOperation;
    bool                success = false;

    newOperation = AllocOperation( 4 );

    if( newOperation )
    {
        SgPoint corners[4];

        corners[0].X = UpperLeft.X;  corners[0].Y = UpperLeft.Y;
        corners[1].X = LowerRight.X; corners[1].Y = UpperLeft.Y;
        corners[2].X = LowerRight.X; corners[2].Y = LowerRight.Y;
        corners[3].X = UpperLeft.X;  corners[3].Y = LowerRight.Y;

        // Build up operation
        newOperation->Operation = OPERATION_POLYLINE;
        DefinePoint( newOperation->Points[0], corners[0] );
        DefinePoint( newOperation->Points[1], corners[1] );
        DefinePoint( newOperation->Points[2], corners[2] );
        DefinePoint( newOperation->Points[3], corners[3] );
        DefineColour( newOperation->Colour, Colour );

        AddOperationToList( newOperation );
    }
    else
    {
        // Unable to allocate memory
        success = false;
    }

    return success;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SgDrawTriangle
//
//  Draws an outline of a triangle specified by three coordinates in the specified colour. 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool
    SgDrawTriangle
    (
        SgPoint     Point1,
        SgPoint     Point2,
        SgPoint     Point3,
        SgColour    Colour
    )
{
    DrawOperations*     newOperation;
    bool                success = false;

    newOperation = AllocOperation( 3 );

    if( newOperation )
    {
        // Build up operation
        newOperation->Operation = OPERATION_POLYLINE;
        DefinePoint( newOperation->Points[0], Point1 );
        DefinePoint( newOperation->Points[1], Point2 );
        DefinePoint( newOperation->Points[2], Point3 );
        DefineColour( newOperation->Colour, Colour );

        AddOperationToList( newOperation );
    }
    else
    {
        // Unable to allocate memory
        success = false;
    }

    return success;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SgDrawQuadrangle
//
//  Draws an outline of a quadrangle specified by four coordinates in the specified colour. 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool
    SgDrawQuadrangle
    (
        SgPoint     Point1,
        SgPoint     Point2,
        SgPoint     Point3,
        SgPoint     Point4,
        SgColour    Colour
    )
{
    DrawOperations*     newOperation;
    bool                success = false;

    newOperation = AllocOperation( 4 );

    if( newOperation )
    {
        // Build up operation
        newOperation->Operation = OPERATION_POLYLINE;
        DefinePoint( newOperation->Points[0], Point1 );
        DefinePoint( newOperation->Points[1], Point2 );
        DefinePoint( newOperation->Points[2], Point3 );
        DefinePoint( newOperation->Points[3], Point4 );
        DefineColour( newOperation->Colour, Colour );

        AddOperationToList( newOperation );
    }
    else
    {
        // Unable to allocate memory
        success = false;
    }

    return success;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SgFillRectangle
//
//  Draws a solid rectangle specified by upper left and lower right corner points in the specified colour. 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool
    SgFillRectangle
    (
        SgPoint     UpperLeft,
        SgPoint     LowerRight,
        SgColour    Colour
    )
{
    DrawOperations*     newOperation;
    bool                success = false;

    newOperation = AllocOperation( 4 );

    if( newOperation )
    {
        SgPoint corners[4];
        // Build up operation

        corners[0].X = UpperLeft.X;  corners[0].Y = UpperLeft.Y;
        corners[1].X = LowerRight.X; corners[1].Y = UpperLeft.Y;
        corners[2].X = LowerRight.X; corners[2].Y = LowerRight.Y;
        corners[3].X = UpperLeft.X;  corners[3].Y = LowerRight.Y;

        // Build up operation
        newOperation->Operation = OPERATION_POLYGON;
        DefinePoint( newOperation->Points[0], corners[0] );
        DefinePoint( newOperation->Points[1], corners[1] );
        DefinePoint( newOperation->Points[2], corners[2] );
        DefinePoint( newOperation->Points[3], corners[3] );
        DefineColour( newOperation->Colour, Colour );
        AddOperationToList( newOperation );
    }
    else
    {
        // Unable to allocate memory
        success = false;
    }

    return success;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SgFillTriangle
//
//  Draws a solid triangle specified by three coordinates in the specified colour. 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool
    SgFillTriangle
    (
        SgPoint     Point1,
        SgPoint     Point2,
        SgPoint     Point3,
        SgColour    Colour
    )
{
    DrawOperations*     newOperation;
    bool                success = false;

    newOperation = AllocOperation( 3 );

    if( newOperation )
    {
        // Build up operation
        newOperation->Operation = OPERATION_POLYGON;
        DefinePoint( newOperation->Points[0], Point1 );
        DefinePoint( newOperation->Points[1], Point2 );
        DefinePoint( newOperation->Points[2], Point3 );
        DefineColour( newOperation->Colour, Colour );

        AddOperationToList( newOperation );
    }
    else
    {
        // Unable to allocate memory
        success = false;
    }

    return success;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  SgFillQuadrangle
//
//  Draws a solid quadrangle specified by four coordinates in the specified colour. 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool
    SgFillQuadrangle
    (
        SgPoint     Point1,
        SgPoint     Point2,
        SgPoint     Point3,
        SgPoint     Point4,
        SgColour    Colour
    )
{
    DrawOperations*     newOperation;
    bool                success = false;

    newOperation = AllocOperation( 4 );

    if( newOperation )
    {
        // Build up operation
        newOperation->Operation = OPERATION_POLYGON;
        DefinePoint( newOperation->Points[0], Point1 );
        DefinePoint( newOperation->Points[1], Point2 );
        DefinePoint( newOperation->Points[2], Point3 );
        DefinePoint( newOperation->Points[3], Point4 );
        DefineColour( newOperation->Colour, Colour );

        AddOperationToList( newOperation );
    }
    else
    {
        // Unable to allocate memory
        success = false;
    }

    return success;
}
