///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Graph3D
//
//  Fun with 3D wire frame graphics
//
//  This is free and unencumbered software released into the public domain - July 2013 waterjuice.org
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  IMPORTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "LibSimpleGraphics.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  CONSTANTS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define WINDOW_SIZE_X       600
#define WINDOW_SIZE_Y       600

#define MESH_GRID_POINTS    500

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  PROTOTYPES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

typedef 
double
    (*PlotFunction3D)
    (
        double  X,
        double  Y
    );

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  TYPES
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
typedef struct
{
    double mesh [MESH_GRID_POINTS+1][MESH_GRID_POINTS+1];
} MeshPoints;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  GLOBALS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static bool    gShowWire = false;
static bool    gShowSurface = false;
static bool    gShowColourSurface = false;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  CalculateMeshCoordinates
//
//  Calcualtes the 3D coordinates for the mesh using the plot function
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    CalculateMeshCoordinates
    (
        PlotFunction3D  Function,
        MeshPoints*     MeshXCoord,
        MeshPoints*     MeshYCoord,
        MeshPoints*     MeshZCoord
    )
{
    double x;
    double y;
    double z;
    int ix;
    int iy;

    for( ix=0; ix<=MESH_GRID_POINTS; ix++ )
    {
        x = (double)ix / MESH_GRID_POINTS;
        for( iy=0; iy<=MESH_GRID_POINTS; iy++ )
        {
            y = (double)iy / MESH_GRID_POINTS;

            // call plot function to get Z
            z = Function( x, y );
            if( z < 0.0 ) { z = 0.0; }
            if( z > 1.0 ) { z = 1.0; }

            MeshXCoord->mesh[ix][iy] = x;
            MeshYCoord->mesh[ix][iy] = y;
            MeshZCoord->mesh[ix][iy] = z;
        }
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  GetPointFrom3D
//
//  Gets a SgPoint value from a 3D coordinate where x,y,z are between 0 and 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
SgPoint
    GetPointFrom3D
    (
        double  x,
        double  y,
        double  z
    )
{
    SgPoint point;
    double X;
    double Y;

    X = (x*0.8) + (y*0.4);
    Y = (y*0.5) + (z*0.6);

    point.X = (uint16_t) (X * (double)WINDOW_SIZE_X * 0.8);
    point.Y = WINDOW_SIZE_Y - (uint16_t) (Y * (double)WINDOW_SIZE_Y * 0.8);

    return point;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  DrawPlotFunction3DWireMesh
//
//  Draws a wire frame mesh using the supplied function to generate the Z value for X and Y values provided by this
//  function
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    DrawPlotFunction3DWireMesh
    (
        PlotFunction3D  Function
    )
{
    MeshPoints* meshXCoord;
    MeshPoints* meshYCoord;
    MeshPoints* meshZCoord;
    int ix;
    int iy;

    SgPoint prevPoint;
    SgPoint point;

    meshXCoord = malloc( sizeof(MeshPoints) );
    meshYCoord = malloc( sizeof(MeshPoints) );
    meshZCoord = malloc( sizeof(MeshPoints) );

    // Calculate mesh coordinates
    CalculateMeshCoordinates( Function, meshXCoord, meshYCoord, meshZCoord );

    // Draw mesh lines along X
    for( ix=0; ix<=MESH_GRID_POINTS; ix+=10 )
    {
        for( iy=10; iy<=MESH_GRID_POINTS; iy+=10 )
        {
            // Draw line segment from previous point to this one
            prevPoint = GetPointFrom3D( meshXCoord->mesh[ix][iy-10], meshYCoord->mesh[ix][iy-10], meshZCoord->mesh[ix][iy-10] );
            point = GetPointFrom3D( meshXCoord->mesh[ix][iy], meshYCoord->mesh[ix][iy], meshZCoord->mesh[ix][iy] );

            SgDrawLine( prevPoint, point, SgRGB(0,0,0) );
        }
    }

    // Draw mesh lines along Y
    for( iy=0; iy<=MESH_GRID_POINTS; iy+=10 )
    {
        for( ix=10; ix<=MESH_GRID_POINTS; ix+=10 )
        {
            // Draw line segment from previous point to this one
            prevPoint = GetPointFrom3D( meshXCoord->mesh[ix-10][iy], meshYCoord->mesh[ix-10][iy], meshZCoord->mesh[ix-10][iy] );
            point = GetPointFrom3D( meshXCoord->mesh[ix][iy], meshYCoord->mesh[ix][iy], meshZCoord->mesh[ix][iy] );

            SgDrawLine( prevPoint, point, SgRGB(0,0,0) );
        }
    }

    free( meshXCoord );
    free( meshYCoord );
    free( meshZCoord );
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  DrawPlotFunction3DSolidWire
//
//  Draws a 3D surface by drawing filled rectangles between sets of 4 mesh points
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    DrawPlotFunction3DSolidWire
    (
        PlotFunction3D  Function
    )
{
    MeshPoints* meshXCoord;
    MeshPoints* meshYCoord;
    MeshPoints* meshZCoord;
    int ix;
    int iy;

    SgPoint points[4];

    meshXCoord = malloc( sizeof(MeshPoints) );
    meshYCoord = malloc( sizeof(MeshPoints) );
    meshZCoord = malloc( sizeof(MeshPoints) );

    // Calculate mesh coordinates
    CalculateMeshCoordinates( Function, meshXCoord, meshYCoord, meshZCoord );

    // Draw quadrangles between sets of 4 points
    for( iy=MESH_GRID_POINTS; iy>10; iy-=10 )
    {
        for( ix=10; ix<=MESH_GRID_POINTS; ix+=10 )
        {
            points[0] = GetPointFrom3D( meshXCoord->mesh[ix-10][iy-10], meshYCoord->mesh[ix-10][iy-10], meshZCoord->mesh[ix-10][iy-10] );
            points[1] = GetPointFrom3D( meshXCoord->mesh[ix][iy-10], meshYCoord->mesh[ix][iy-10], meshZCoord->mesh[ix][iy-10] );
            points[2] = GetPointFrom3D( meshXCoord->mesh[ix][iy], meshYCoord->mesh[ix][iy], meshZCoord->mesh[ix][iy] );
            points[3] = GetPointFrom3D( meshXCoord->mesh[ix-10][iy], meshYCoord->mesh[ix-10][iy], meshZCoord->mesh[ix-10][iy] );

            SgFillQuadrangle( points[0], points[1], points[2], points[3], SgRGB(255,255,255) );
            SgDrawQuadrangle( points[0], points[1], points[2], points[3], SgRGB(0,0,0) );
        }
    }

    free( meshXCoord );
    free( meshYCoord );
    free( meshZCoord );
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  DrawPlotFunction3DSurface
//
//  Draws a 3D surface by drawing filled rectangles between sets of 4 mesh points
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    DrawPlotFunction3DSurface
    (
        PlotFunction3D  Function
    )
{
    MeshPoints* meshXCoord;
    MeshPoints* meshYCoord;
    MeshPoints* meshZCoord;
    int ix;
    int iy;

    SgPoint points[4];
    SgColour colour;

    meshXCoord = malloc( sizeof(MeshPoints) );
    meshYCoord = malloc( sizeof(MeshPoints) );
    meshZCoord = malloc( sizeof(MeshPoints) );

    // Calculate mesh coordinates
    CalculateMeshCoordinates( Function, meshXCoord, meshYCoord, meshZCoord );

    // Draw quadrangles between sets of 4 points
    for( iy=MESH_GRID_POINTS; iy>0; iy-- )
    {
        for( ix=1; ix<=MESH_GRID_POINTS; ix++ )
        {
            points[0] = GetPointFrom3D( meshXCoord->mesh[ix-1][iy-1], meshYCoord->mesh[ix-1][iy-1], meshZCoord->mesh[ix-1][iy-1] );
            points[1] = GetPointFrom3D( meshXCoord->mesh[ix][iy-1], meshYCoord->mesh[ix][iy-1], meshZCoord->mesh[ix][iy-1] );
            points[2] = GetPointFrom3D( meshXCoord->mesh[ix][iy], meshYCoord->mesh[ix][iy], meshZCoord->mesh[ix][iy] );
            points[3] = GetPointFrom3D( meshXCoord->mesh[ix-1][iy], meshYCoord->mesh[ix-1][iy], meshZCoord->mesh[ix-1][iy] );

            colour = SgRGB(50+(double)meshZCoord->mesh[ix][iy]*255,0,0);

            SgFillQuadrangle( points[0], points[1], points[2], points[3], colour );
        }
    }

    free( meshXCoord );
    free( meshYCoord );
    free( meshZCoord );
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  RippleFunction
//
//  This function is a 3d plot function. It provides a Z value for given X and Y. All values are between 0 and 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
double
    RippleFunction
    (
        double  x,
        double  y
    )
{
    double pi = 3.14159265358979;
    double z;
    double dist;
    double wave;

    // Get distance of point from centre (0.5, 0.5)
    dist = sqrt( (0.5-x)*(0.5-x) + (0.5-y)*(0.5-y) );

    wave = sin( 4*(2*pi) * dist ) * 0.4;
    z = (wave / 2.0) + 0.5;

    if( dist > 0.5 ) 
    {
        z = 0.5;
    }

    return z;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  GraphicsFunction
//
//  Entry point
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
    GraphicsFunction
    (
        void*   Unused
    )
{
    char buffer [100];
    char* ptr;
    (void)Unused;

    if( gShowWire )
    {
        DrawPlotFunction3DWireMesh( RippleFunction );
    }
    if( gShowSurface )
    {
        DrawPlotFunction3DSolidWire( RippleFunction );
    }
    if( gShowColourSurface )
    {
        DrawPlotFunction3DSurface( RippleFunction );
    }

    // Wait for user to press enter before returning and closing window
    ptr = fgets( buffer, sizeof(buffer), stdin );
    (void)ptr;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  main
//
//  Entry point
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int
    main
    (
        int     ArgC,
        char*   ArgV[]
    )
{

    if( 1 == ArgC )
    {
        // defaults
        gShowWire = false;
        gShowSurface = false;
        gShowColourSurface = true;
    }
    else if( 2 == ArgC )
    {
        if( ArgV[1][0] == 'w' )
        {
            gShowWire = true;
        }
        else if( ArgV[1][0] == 's' )
        {
            gShowSurface = true;
        }
        else if( ArgV[1][0] == 'c' )
        {
            gShowColourSurface = true;
        }
        else if( ArgV[1][0] == 'd' )
        {
            gShowWire = true;
//            gShowSurface = true;
            gShowColourSurface = true;
        }
        else
        {
            printf( "Invalid mode specified\n" );
            return 1;
        }
    }
    else
    {
        printf( 
            "Syntax\n"
            "   Graph3D [Mode]\n"
            "      [Mode] - w (wire frame)\n"
            "      [Mode] - s (surface)\n"
            "      {Mode] - c (colour smooth surface)\n" );
        return 1;
    }

    SimpleGraphicsRun( WINDOW_SIZE_X, WINDOW_SIZE_Y, "Graph3D", GraphicsFunction, 0 );

    return 0;
}
